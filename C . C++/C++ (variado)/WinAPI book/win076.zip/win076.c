#include <windows.h>

#include "IDS.h"

/*  Declaraci�n del procedimiento de ventana  */
LRESULT CALLBACK WindowProcedure (HWND, UINT, WPARAM, LPARAM);

int WINAPI WinMain (HINSTANCE hThisInstance,
                    HINSTANCE hPrevInstance,
                    LPSTR lpszArgument,
                    int nFunsterStil)
{
    HWND hwnd;               /* Manipulador de ventana */
    MSG mensaje;             /* Mensajes recibidos por la aplicaci�n */
    WNDCLASSEX wincl;        /* Estructura de datos para la clase de ventana */

    /* Estructura de la ventana */
    wincl.hInstance = hThisInstance;
    wincl.lpszClassName = "NUESTRA_CLASE";
    wincl.lpfnWndProc = WindowProcedure;      /* Esta funci�n es invocada por Windows */
    wincl.style = CS_DBLCLKS;                 /* Captura los doble-clicks */
    wincl.cbSize = sizeof (WNDCLASSEX);

    /* Usar icono y puntero por defector */
    wincl.hIcon = LoadIcon (NULL, IDI_APPLICATION);
    wincl.hIconSm = LoadIcon (NULL, IDI_APPLICATION);
    wincl.hCursor = LoadCursor (NULL, IDC_ARROW);
    wincl.lpszMenuName = "Menu";
    wincl.cbClsExtra = 0;                      /* Sin informaci�n adicional para la */
    wincl.cbWndExtra = 0;                      /* clase o la ventana */
    /* Usar el color de fondo por defecto para la ventana */
    wincl.hbrBackground =  GetSysColorBrush(COLOR_MENU); //COLOR_BACKGROUND);

    /* Registrar la clase de ventana, si falla, salir del programa */
    if(!RegisterClassEx(&wincl)) return 0;

    /* La clase est� registrada, crear la ventana */
    hwnd = CreateWindowEx(
           0,                   /* Posibilidades de variaci�n */
           "NUESTRA_CLASE",     /* Nombre de la clase */
           "Ejemplo 076",       /* Texto del t�tulo */
           WS_OVERLAPPEDWINDOW, /* Tipo por defecto */
           CW_USEDEFAULT,       /* Windows decide la posici�n */
           CW_USEDEFAULT,       /* donde se coloca la ventana */
           544,                 /* Ancho */
           455,                 /* Alto en pixels */
           HWND_DESKTOP,        /* La ventana es hija del escritorio */
           NULL,                /* Sin men� */
           hThisInstance,       /* Manipulador de instancia */
           NULL                 /* No hay datos de creaci�n de ventana */
    );

    /* Mostrar la ventana */
    ShowWindow(hwnd, SW_SHOWDEFAULT);

    /* Bucle de mensajes, se ejecuta hasta que haya error o GetMessage devuelva FALSE */
    while(TRUE == GetMessage(&mensaje, NULL, 0, 0))
    {
       if(!IsDialogMessage(hwnd, &mensaje) ) {
        /* Traducir mensajes de teclas virtuales a mensajes de caracteres */
        TranslateMessage(&mensaje);
        /* Enviar mensaje al procedimiento de ventana */
        DispatchMessage(&mensaje);
        }
    }

    /* Salir con valor de retorno */
    return mensaje.wParam;
}

/*  Esta funci�n es invocada por la funci�n DispatchMessage()  */
LRESULT CALLBACK WindowProcedure(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
    /* Variables para di�logo */
    static HINSTANCE hInstance;
    static HBITMAP hBitmap;
    static BITMAP bm;
    static RECT re;
    static int xMin;
    static int xActual;
    static int xMax;
    HWND hctrl;
    SCROLLINFO si;
    HDC hdc;
    PAINTSTRUCT ps;
    HDC memDC;
    RECT red;
    int xNuevo, xDelta;
    int xo, w;
    
    switch (msg)              /* manipulador del mensaje */
    {
        case WM_CREATE:
           hInstance = ((LPCREATESTRUCT)lParam)->hInstance;
           /* Insertar control */
           hctrl = CreateWindowEx(
              0,
              "SCROLLBAR",    /* Nombre de la clase */
              NULL,           /* Texto del t�tulo */
              SBS_HORZ | SBS_TOPALIGN |
              WS_CHILD | WS_VISIBLE | WS_TABSTOP, /* Estilo */
              25, 0,          /* Posici�n */
              180, 28,        /* Tama�o */
              hwnd,           /* Ventana padre */
              (HMENU)ID_SCR1, /* Identificador del control */
              hInstance,      /* Instancia */
              NULL);          /* Sin datos de creaci�n de ventana */
           CreateWindowEx(
              0,
              "BUTTON",
              "Salir",
              WS_CHILD | WS_VISIBLE | WS_TABSTOP, /* Estilo */
              45, 35,          /* Posici�n */
              120, 25,         /* Tama�o */
              hwnd,            /* Ventana padre */
              (HMENU)CM_SALIR, /* Identificador del control */
              hInstance,       /* Instancia */
              NULL);
           hBitmap = LoadBitmap(hInstance, "Meninas");
           GetObject(hBitmap, sizeof(BITMAP), (LPSTR)&bm);
           SetRect(&re, 25, 25, 25+bm.bmWidth, 25+bm.bmHeight);
           xMin = -bm.bmWidth;
           xMax = bm.bmWidth;
           xActual = 0;
           si.cbSize = sizeof(si); 
           si.fMask  = SIF_RANGE | SIF_PAGE | SIF_POS; 
           si.nMin   = xMin; 
           si.nMax   = xMax; 
           si.nPage  = 10; 
           si.nPos   = xActual; 
           SetScrollInfo(GetDlgItem(hwnd, ID_SCR1), SB_CTL, &si, TRUE); 
           SetFocus(hctrl);
           return 0;
        case WM_HSCROLL:
           xNuevo = xActual;
           si.cbSize = sizeof(si); 
           si.fMask  = SIF_POS; 
           GetScrollInfo(GetDlgItem(hwnd, ID_SCR1), SB_CTL, &si);
           switch(LOWORD(wParam)) {
              case SB_LINERIGHT: xNuevo++; break;
              case SB_LINELEFT:  xNuevo--; break;
              case SB_PAGERIGHT: xNuevo += 10; break;
              case SB_PAGELEFT:  xNuevo -= 10; break;
              case SB_THUMBTRACK: 
              case SB_THUMBPOSITION:
                   xNuevo = (int)wParam>>16; break;
           }
           xNuevo = max(xMin, xNuevo); 
           xNuevo = min(xMax, xNuevo); 
           xDelta = xNuevo - xActual;
           xActual = xNuevo;
           ScrollWindowEx(hwnd, -xDelta, 0, &re, &re, 
             (HRGN) NULL, (LPRECT) NULL, 
             SW_INVALIDATE | SW_SCROLLCHILDREN); 
           UpdateWindow(hwnd); 
 
           /* Actualizar barra de desplazamiento. */ 
           si.cbSize = sizeof(si); 
           si.fMask  = SIF_POS; 
           si.nPos   = xActual; 
           SetScrollInfo(GetDlgItem(hwnd, ID_SCR1), SB_CTL, &si, TRUE); 
           break;
        case WM_COMMAND:
           switch(LOWORD(wParam)) {
              case CM_SALIR:
                DestroyWindow(hwnd);
                break;
           }
           break;
        case WM_SIZE:
           InvalidateRect(hwnd, &re, FALSE);
           return 0;
           break;
        case WM_PAINT:
           hdc = BeginPaint(hwnd, &ps);
           memDC = CreateCompatibleDC(hdc);
           SelectObject(memDC, hBitmap);
           IntersectRect(&red, &ps.rcPaint, &re);
           xo = xActual+red.left-re.left;
           while(xo < 0) xo += bm.bmWidth;
           while(xo >= bm.bmWidth) xo -= bm.bmWidth;
           
           BitBlt(hdc, red.left, re.top,
              red.right-red.left, red.bottom-red.top,
              memDC, xo, red.top-re.top,
              SRCCOPY);
           if(xo+red.right-red.left > bm.bmWidth) {
              w = xo+red.right-red.left - bm.bmWidth;
              xo = 0;
              BitBlt(hdc, red.right-w, re.top,
                 w, red.bottom-red.top,
                 memDC, xo, red.top-re.top,
                 SRCCOPY);
           }
           DeleteDC(memDC);
           EndPaint(hwnd, &ps);
           break;
        case WM_DESTROY:
           DeleteObject(hBitmap);
           PostQuitMessage(0);    /* env�a un mensaje WM_QUIT a la cola de mensajes */
           break;
        default:                  /* para los mensajes de los que no nos ocupamos */
           return DefWindowProc(hwnd, msg, wParam, lParam);
    }
    return 0;
}
