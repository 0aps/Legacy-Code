/* Identificadores */ 

/* Identificadores de comandos */
#define CM_DIALOGO      101
#define ID_SCR1         102
#define ID_ESTATICO     103
#define CM_SALIR        180
