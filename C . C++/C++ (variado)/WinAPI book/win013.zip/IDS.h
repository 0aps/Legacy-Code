/* Identificadores */

/* Identificadores de comandos */
#define CM_DIALOGO 101

#define ID_GROUPBOX1	101
#define ID_GROUPBOX2	102
#define ID_BOTON1       103
#define ID_BOTON2       104
#define ID_BOTON3       105
#define ID_BOTON4       106
#define ID_BOTON5       107
#define ID_BOTON6       108

