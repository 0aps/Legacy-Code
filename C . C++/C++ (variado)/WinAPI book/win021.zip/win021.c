#include <windows.h>
#include <string.h>
#include <stdio.h>
#include "ids.h"

/* Declaraci�n del procedimiento de ventana */
LRESULT CALLBACK WindowProcedure(HWND, UINT, WPARAM, LPARAM);

void LlenarPantalla(HDC, HWND, HBITMAP);
void CBitBlt(HDC, HWND, HBITMAP);
void CTrozo(HDC, HWND, HBITMAP);
void CStretchBlt(HDC, HWND, HBITMAP);
void CAmpliacion(HDC, HWND, HBITMAP);
void CPlgBlt(HDC, HWND, HBITMAP, HBITMAP);
void CMaskBlt(HDC, HWND, HBITMAP, HBITMAP);
void CBitBltROP(HDC, HWND, HBITMAP, HBITMAP, HBITMAP, DWORD);
void CPatBlt(HDC, HWND, HBITMAP);
void CFloodFill(HDC, HWND, int, int, HBITMAP);
void CEstrechar(HDC, HWND, HBITMAP, int);
void CStock(HDC, HWND);

int WINAPI WinMain (HINSTANCE hThisInstance,
                    HINSTANCE hPrevInstance,
                    LPSTR lpszArgument,
                    int nFunsterStil)
{
    HWND hwnd;               /* Manipulador de ventana */
    MSG mensaje;             /* Mensajes recibidos por la aplicaci�n */
    WNDCLASSEX wincl;        /* Estructura de datos para la clase de ventana */

    /* Estructura de la ventana */
    wincl.hInstance = hThisInstance;
    wincl.lpszClassName = "NUESTRA_CLASE";
    wincl.lpfnWndProc = WindowProcedure;      /* Esta funci�n es invocada por Windows */
    wincl.style = CS_DBLCLKS;                 /* Captura los doble-clicks */
    wincl.cbSize = sizeof (WNDCLASSEX);

    /* Usar icono y puntero por defector */
    wincl.hIcon = LoadIcon (hThisInstance, "Icono");
    wincl.hIconSm = LoadIcon (hThisInstance, "Icono");
    wincl.hCursor = LoadCursor (NULL, IDC_ARROW);
    wincl.lpszMenuName = "Menu";
    wincl.cbClsExtra = 0;                      /* Sin informaci�n adicional para la */
    wincl.cbWndExtra = 0;                      /* clase o la ventana */
    /* Usar el color de fondo por defecto para es escritorio */
    wincl.hbrBackground = GetSysColorBrush(COLOR_BACKGROUND);

    /* Registrar la clase de ventana, si falla, salir del programa */
    if(!RegisterClassEx(&wincl)) return 0;
      
    /* La clase est� registrada, crear la ventana */
    hwnd = CreateWindowEx(
           0,                   /* Posibilidades de variaci�n */
           "NUESTRA_CLASE",     /* Nombre de la clase */
           "Ejemplo 021",       /* Texto del t�tulo */
           WS_OVERLAPPEDWINDOW, /* Tipo por defecto */
           CW_USEDEFAULT,       /* Windows decide la posici�n */
           CW_USEDEFAULT,       /* donde se coloca la ventana */
           450,
           450,
           HWND_DESKTOP,        /* La ventana es hija del escritorio */
           NULL,                /* Sin men� */
           hThisInstance,       /* Manipulador de instancia */
           NULL                 /* No hay datos de creaci�n de ventana */
    );

    /* Mostrar la ventana */
    ShowWindow(hwnd, SW_SHOWDEFAULT);

    /* Bucle de mensajes, se ejecuta hasta que haya error o GetMessage devuelva FALSE */
    while(TRUE == GetMessage(&mensaje, NULL, 0, 0))
    {
        /* Traducir mensajes de teclas virtuales a mensajes de caracteres */
        TranslateMessage(&mensaje);
        /* Enviar mensaje al procedimiento de ventana */
        DispatchMessage(&mensaje);
    }

    /* Salir con valor de retorno */
    return mensaje.wParam;
}

/* Esta funci�n es llamada por la funci�n del API DispatchMessage() */
LRESULT CALLBACK WindowProcedure(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
    HDC hDC;
    PAINTSTRUCT ps;
    static HINSTANCE hInstance;
    static HBITMAP hBitmapRes;
    static HBITMAP hBitmapFil;
    static HBITMAP hMascara;
    static HBITMAP hBitmapLazo;
    static UINT comando;
    
    switch (msg)                  /* manipulador del mensaje */
    {
        case WM_CREATE:
           hInstance = ((LPCREATESTRUCT)lParam)->hInstance;
           hBitmapRes = LoadBitmap(hInstance, "Bitmap");
           hMascara = LoadBitmap(hInstance, MAKEINTRESOURCE(MASCARA));
           hBitmapLazo = LoadBitmap(hInstance, "Lazo");
           hBitmapFil = (HBITMAP)LoadImage(NULL, "mosca24.bmp", IMAGE_BITMAP,
              0, 0, LR_LOADFROMFILE);
           //comando = CM_BITBLT;
           break;
        case WM_PAINT:
           hDC = BeginPaint(hwnd, &ps);
           switch(comando) {
              case CM_RECURSO: 
                 LlenarPantalla(hDC, hwnd, hBitmapRes);
                 break;
              case CM_FICHERO:
                 LlenarPantalla(hDC, hwnd, hBitmapFil);
                 break;
              case CM_BITBLT:
                 CBitBlt(hDC, hwnd, hBitmapRes);
                 break;
              case CM_TROZO:
                 CTrozo(hDC, hwnd, hBitmapRes);
                 break;
              case CM_STRETCHBLT:
                 CStretchBlt(hDC, hwnd, hBitmapRes);
                 break;
              case CM_AMPLIACION:
                 CAmpliacion(hDC, hwnd, hBitmapRes);
                 break;
              case CM_PLGBLT:
                 CPlgBlt(hDC, hwnd, hBitmapRes, NULL);
                 break;
              case CM_MASCARA:
                 CPlgBlt(hDC, hwnd, hBitmapRes, hMascara);
                 break;
              case CM_MASKBLT:
                 CMaskBlt(hDC, hwnd, hBitmapRes, hMascara);
                 break;
              case CM_BLACKNESS:
                 CBitBltROP(hDC, hwnd, hBitmapRes, hBitmapFil, hBitmapLazo, BLACKNESS);
                 break;
              case CM_DSTINVERT:
                 CBitBltROP(hDC, hwnd, hBitmapRes, hBitmapFil, hBitmapLazo, DSTINVERT);
                 break;
              case CM_MERGECOPY:
                 CBitBltROP(hDC, hwnd, hBitmapRes, hBitmapFil, hBitmapLazo, MERGECOPY);
                 break;
              case CM_MERGEPAINT:
                 CBitBltROP(hDC, hwnd, hBitmapRes, hBitmapFil, hBitmapLazo, MERGEPAINT);
                 break;
              case CM_NOTSRCCOPY:
                 CBitBltROP(hDC, hwnd, hBitmapRes, hBitmapFil, hBitmapLazo, NOTSRCCOPY);
                 break;
              case CM_NOTSRCERASE:
                 CBitBltROP(hDC, hwnd, hBitmapRes, hBitmapFil, hBitmapLazo, NOTSRCERASE);
                 break;
              case CM_PATCOPY:
                 CBitBltROP(hDC, hwnd, hBitmapRes, hBitmapFil, hBitmapLazo, PATCOPY);
                 break;
              case CM_PATINVERT:
                 CBitBltROP(hDC, hwnd, hBitmapRes, hBitmapFil, hBitmapLazo, PATINVERT);
                 break;
              case CM_PATPAINT:
                 CBitBltROP(hDC, hwnd, hBitmapRes, hBitmapFil, hBitmapLazo, PATPAINT);
                 break;
              case CM_SRCAND:
                 CBitBltROP(hDC, hwnd, hBitmapRes, hBitmapFil, hBitmapLazo, SRCAND);
                 break;
              case CM_SRCCOPY:
                 CBitBltROP(hDC, hwnd, hBitmapRes, hBitmapFil, hBitmapLazo, SRCCOPY);
                 break;
              case CM_SRCERASE:
                 CBitBltROP(hDC, hwnd, hBitmapRes, hBitmapFil, hBitmapLazo, SRCERASE);
                 break;
              case CM_SRCINVERT:
                 CBitBltROP(hDC, hwnd, hBitmapRes, hBitmapFil, hBitmapLazo, SRCINVERT);
                 break;
              case CM_SRCPAINT:
                 CBitBltROP(hDC, hwnd, hBitmapRes, hBitmapFil, hBitmapLazo, SRCPAINT);
                 break;
              case CM_WHITENESS:
                 CBitBltROP(hDC, hwnd, hBitmapRes, hBitmapFil, hBitmapLazo, WHITENESS);
                 break;
              case CM_PATBLT:
                 CPatBlt(hDC, hwnd, hBitmapLazo);
                 break;
              case CM_FLOODFILL:
                 CFloodFill(hDC, hwnd, 90, 60, hBitmapLazo);
                 break;
              case CM_COLORONCOLOR:
                 CEstrechar(hDC, hwnd, hBitmapRes, COLORONCOLOR);
                 break;
              case CM_HALFTONE:
                 CEstrechar(hDC, hwnd, hBitmapRes, HALFTONE);
                 break;
              case CM_STOCK:
                 CStock(hDC, hwnd);
                 break;
           }
           EndPaint(hwnd, &ps);
           break;
        case WM_SIZE:
           InvalidateRect(hwnd, NULL, TRUE); //esto hace que se vuelva a pintar cada vez que
                                            // se cambia el tamanyo de la ventana.
           break;
        case WM_COMMAND:
           comando = LOWORD(wParam);
           InvalidateRect(hwnd, NULL, TRUE); //si es true se borra lo anterior
                                             //si es false se sobrepinta. =P  
           break;
        case WM_DESTROY:
           DeleteObject(hBitmapLazo);
           DeleteObject(hBitmapRes);
           DeleteObject(hBitmapFil);
           DeleteObject(hMascara);
           PostQuitMessage(0);    /* env�a un mensaje WM_QUIT a la cola de mensajes */
           break;
        default:                  /* para los mensajes de los que no nos ocupamos */
           return DefWindowProc(hwnd, msg, wParam, lParam);
    }
    return 0;
}

void LlenarPantalla(HDC hDC, HWND hWnd, HBITMAP hBitmap)
{
    HDC memDC;
    BITMAP bm;
    int x, y;
    RECT re;
    
    memDC = CreateCompatibleDC(hDC);
    SelectObject(memDC, hBitmap);
    GetObject(hBitmap, sizeof(BITMAP), (LPSTR)&bm);
    GetClientRect(hWnd, &re);
    y = 0;
    while(y < re.bottom) {
       x = 0;
       while(x < re.right) {
          BitBlt(hDC, x, y, bm.bmWidth, bm.bmHeight, memDC, 0, 0, SRCCOPY);
          x+=bm.bmWidth;
       }
       y+=bm.bmHeight;
    }
    DeleteDC(memDC);           
}

void CBitBlt(HDC hDC, HWND hWnd, HBITMAP hBitmap)
{
    HDC memDC;
    RECT re;

    memDC = CreateCompatibleDC(hDC);
    SelectObject(memDC, hBitmap);
    GetClientRect(hWnd, &re);
    BitBlt(hDC, 0, 0, re.right, re.bottom, memDC, 0, 0, SRCCOPY);
    DeleteDC(memDC);           
}

void CTrozo(HDC hDC, HWND hWnd, HBITMAP hBitmap)
{
    HDC memDC;

    memDC = CreateCompatibleDC(hDC);
    SelectObject(memDC, hBitmap);
    BitBlt(hDC, 135, 225, 40, 40, memDC, 135, 225, SRCCOPY);
    DeleteDC(memDC);           
}

void CStretchBlt(HDC hDC, HWND hWnd, HBITMAP hBitmap)
{
    HDC memDC;
    BITMAP bm;
    RECT re;

    memDC = CreateCompatibleDC(hDC);
    SelectObject(memDC, hBitmap);
    GetObject(hBitmap, sizeof(BITMAP), (LPSTR)&bm); //optengo el tamanyo de hBitmap y se guarda en bm
    GetClientRect(hWnd, &re);
    StretchBlt(hDC, 0, 0, re.right, re.bottom, memDC, 
                    0, 0, bm.bmWidth, bm.bmHeight, SRCCOPY);
    DeleteDC(memDC);           
}

void CAmpliacion(HDC hDC, HWND hWnd, HBITMAP hBitmap)
{
    HDC memDC;
    BITMAP bm;
    RECT re;

    memDC = CreateCompatibleDC(hDC);
    SelectObject(memDC, hBitmap);
    GetObject(hBitmap, sizeof(BITMAP), (LPSTR)&bm);
    GetClientRect(hWnd, &re);
    StretchBlt(hDC, 0, 0, re.right, re.bottom, memDC, 
                    135, 225, 40, 40, SRCCOPY);
    DeleteDC(memDC);           
}

void CPlgBlt(HDC hDC, HWND hWnd, HBITMAP hBitmap, HBITMAP hMascara)
{
    HDC memDC;
    BITMAP bm;
    RECT re;
    POINT punto[3];

    memDC = CreateCompatibleDC(hDC);
    SelectObject(memDC, hBitmap);
    GetObject(hBitmap, sizeof(BITMAP), (LPSTR)&bm);
    GetClientRect(hWnd, &re);
    punto[0].x = 0;
    punto[0].y = 0;
    punto[1].x = 2*re.right/3;
    punto[1].y = re.bottom/4;
    punto[2].x = re.right/3;
    punto[2].y = 3*re.bottom/4;
    PlgBlt(hDC, punto, memDC, 0, 0, bm.bmWidth, bm.bmHeight, hMascara, 0, 0);
    DeleteDC(memDC);           
}

void CMaskBlt(HDC hDC, HWND hWnd, HBITMAP hBitmap, HBITMAP hMascara)
{
    HDC memDC;
    BITMAP bm;
    RECT re;
    HBRUSH anterior;

    memDC = CreateCompatibleDC(hDC);
    SelectObject(memDC, hBitmap);
    anterior = SelectObject(hDC, GetSysColorBrush(COLOR_BACKGROUND));
    GetObject(hBitmap, sizeof(BITMAP), (LPSTR)&bm);
    GetClientRect(hWnd, &re);
    MaskBlt(hDC, 0, 0, bm.bmWidth, bm.bmHeight, memDC, 0, 0, 
       hMascara, 0, 0, MAKEROP4(PATCOPY, SRCCOPY));
    SelectObject(hDC, anterior);
    DeleteDC(memDC);           
}

void CBitBltROP(HDC hDC, HWND hWnd, 
   HBITMAP hBitmap1, HBITMAP hBitmap2, HBITMAP lazo, DWORD ROP)
{
    HDC memDC;
    BITMAP bm;
    HBRUSH pincel, anterior;
    
    // Crear una brocha:
    pincel = CreatePatternBrush(lazo);
    if(pincel) MessageBox(hWnd, "No puedo crear el pincel", "Error", MB_OK);
    anterior = SelectObject(hDC, pincel);
    
    GetObject(hBitmap1, sizeof(BITMAP), (LPSTR)&bm);
    memDC = CreateCompatibleDC(hDC);
    SelectObject(memDC, hBitmap1);
    BitBlt(hDC, 0, 0, bm.bmWidth, bm.bmHeight, memDC, 0, 0, SRCCOPY);
    SelectObject(memDC, hBitmap2);
    BitBlt(hDC, 40, 40, bm.bmWidth, bm.bmHeight, memDC, 0, 0, ROP);
    DeleteDC(memDC);           
    
    SelectObject(hDC, anterior);  
    DeleteObject(pincel);
}

void CPatBlt(HDC hDC, HWND hWnd, HBITMAP hBitmap)
{
    HBRUSH pincel, anterior;
    RECT re;
    
    // Crear una brocha:
    pincel = CreatePatternBrush(hBitmap);
    if(!pincel) MessageBox(hWnd, "No puedo crear el pincel", "Error", MB_OK);
    anterior = SelectObject(hDC, pincel);
    
    GetClientRect(hWnd, &re);
    PatBlt(hDC, 40, 40, re.right-80, re.bottom-80, PATCOPY);
    
    SelectObject(hDC, anterior);  
    DeleteObject(pincel);
}

void CFloodFill(HDC hDC, HWND hWnd, int x, int y, HBITMAP hBitmap)
{
    HBRUSH pincel, anterior;
    RECT re;
    
    // Crear una brocha:
    pincel = CreatePatternBrush(hBitmap);
    if(!pincel) MessageBox(hWnd, "No puedo crear el pincel", "Error", MB_OK);
    anterior = SelectObject(hDC, pincel);
    
    GetClientRect(hWnd, &re);

    // Pintar una figura:
    MoveToEx(hDC, 40, 40, NULL);
    LineTo(hDC, re.right-80, 50);
    LineTo(hDC, re.right-70, re.bottom-80);
    LineTo(hDC, 50, re.bottom-90);
    LineTo(hDC, re.right/2, re.bottom/2);
    LineTo(hDC, 40, 40);

    // Rellenar:
    ExtFloodFill(hDC, x, y, RGB(0,0,0), FLOODFILLBORDER);
    
    SelectObject(hDC, anterior);  
    DeleteObject(pincel);
}

void CEstrechar(HDC hDC, HWND hWnd, HBITMAP hBitmap, int modo)
{
    HDC memDC;
    BITMAP bm;
    RECT re;

    GetClientRect(hWnd, &re);
    memDC = CreateCompatibleDC(hDC);
    SelectObject(memDC, hBitmap);
    GetObject(hBitmap, sizeof(BITMAP), (LPSTR)&bm);
    SetStretchBltMode(hDC, modo);
    if(modo == HALFTONE) SetBrushOrgEx(hDC, 0, 0, NULL);
    StretchBlt(hDC, 0, 0, re.right, re.bottom, memDC, 
                    0, 0, bm.bmWidth, bm.bmHeight, SRCCOPY);
    DeleteDC(memDC);           
}

void CStock(HDC hDC, HWND hWnd)
{
    HDC memDC;
    BITMAP bm;
    HBITMAP hBitmap;
    RECT re;
    int i;
    int mapa[] = {
        //iconos o stocks 
       OBM_BTNCORNERS, OBM_BTSIZE, OBM_CHECK, OBM_CHECKBOXES, OBM_CLOSE,
       OBM_COMBO, OBM_DNARROW, OBM_DNARROWD, OBM_DNARROWI, OBM_LFARROW,
       OBM_LFARROWD, OBM_LFARROWI, OBM_MNARROW, OBM_REDUCE, OBM_REDUCED,
       OBM_RESTORE, OBM_RESTORED, OBM_RGARROW, OBM_RGARROWD, OBM_RGARROWI,
       OBM_SIZE, OBM_UPARROW, OBM_UPARROWD, OBM_UPARROWI, OBM_ZOOM, OBM_ZOOMD
    };
    
    memDC = CreateCompatibleDC(hDC);
    GetClientRect(hWnd, &re);
    re.left+=10;
    for(i = 0; i < sizeof(mapa)/sizeof(mapa[0]); i++) {
       hBitmap = LoadBitmap(NULL, MAKEINTRESOURCE(mapa[i]));
       SelectObject(memDC, hBitmap);
       GetObject(hBitmap, sizeof(BITMAP), (LPSTR)&bm);
       BitBlt(hDC, re.left, 10, bm.bmWidth, bm.bmHeight, memDC, 0, 0, SRCCOPY);
       re.left += bm.bmWidth+5;
       DeleteObject(hBitmap);
    }
    DeleteDC(memDC);           

}

