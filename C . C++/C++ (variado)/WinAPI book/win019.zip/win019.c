#include <windows.h>
#include <string.h>
#include "IDS.h"

WORD Comando; 
void mChord(HDC hDC);
void mEllipse(HDC hDC);
void mFillRect(HDC hDC, HBRUSH hBrush);
void mFrameRect(HDC hDC, HBRUSH hBrush);
void mPie(HDC hDC);
void mPolygon(HDC hDC);
void mPolyPolygon(HDC hDC);
void mRectangle(HDC hDC);
void mRoundRect(HDC hDC);

/*  Declaraci�n del procedimiento de ventana  */
LRESULT CALLBACK WindowProcedure (HWND, UINT, WPARAM, LPARAM);

int WINAPI WinMain (HINSTANCE hThisInstance,
                    HINSTANCE hPrevInstance,
                    LPSTR lpszArgument,
                    int nFunsterStil)
{
    HWND hwnd;               /* Manipulador de ventana */
    MSG mensaje;             /* Mensajes recibidos por la aplicaci�n */
    WNDCLASSEX wincl;        /* Estructura de datos para la clase de ventana */

    /* Estructura de la ventana */
    wincl.hInstance = hThisInstance;
    wincl.lpszClassName = "NUESTRA_CLASE";
    wincl.lpfnWndProc = WindowProcedure;      /* Esta funci�n es invocada por Windows */
    wincl.style = CS_DBLCLKS;                 /* Captura los doble-clicks */
    wincl.cbSize = sizeof (WNDCLASSEX);

    /* Usar icono y puntero por defector */
    wincl.hIcon = LoadIcon (NULL, IDI_APPLICATION);
    wincl.hIconSm = LoadIcon (NULL, IDI_APPLICATION);
    wincl.hCursor = LoadCursor (NULL, IDC_ARROW);
    wincl.lpszMenuName = "Menu";
    wincl.cbClsExtra = 0;                      /* Sin informaci�n adicional para la */
    wincl.cbWndExtra = 0;                      /* clase o la ventana */
    /* Usar el color de fondo por defecto para la ventana */
    wincl.hbrBackground = GetSysColorBrush(COLOR_BACKGROUND);

    /* Registrar la clase de ventana, si falla, salir del programa */
    if(!RegisterClassEx(&wincl)) return 0;
      
    /* La clase est� registrada, crear la ventana */
    hwnd = CreateWindowEx(
           0,                   /* Posibilidades de variaci�n */
           "NUESTRA_CLASE",     /* Nombre de la clase */
           "Ejemplo 019",       /* Texto del t�tulo */
           WS_OVERLAPPEDWINDOW, /* Tipo por defecto */
           CW_USEDEFAULT,       /* Windows decide la posici�n */
           CW_USEDEFAULT,       /* donde se coloca la ventana */
           544,                 /* Ancho */
           375,                 /* Alto en pixels */
           HWND_DESKTOP,        /* La ventana es hija del escritorio */
           NULL,                /* Sin men� */
           hThisInstance,       /* Manipulador de instancia */
           NULL                 /* No hay datos de creaci�n de ventana */
    );

    /* Mostrar la ventana */
    ShowWindow(hwnd, SW_SHOWDEFAULT);

    /* Bucle de mensajes, se ejecuta hasta que haya error o GetMessage devuelva FALSE */
    while(TRUE == GetMessage(&mensaje, NULL, 0, 0))
    {
        /* Traducir mensajes de teclas virtuales a mensajes de caracteres */
        TranslateMessage(&mensaje);
        /* Enviar mensaje al procedimiento de ventana */
        DispatchMessage(&mensaje);
    }

    /* Salir con valor de retorno */
    return mensaje.wParam;
}

/* Esta funci�n es llamada por la funci�n del API DispatchMessage() */
LRESULT CALLBACK WindowProcedure(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
    HDC hDC;
    PAINTSTRUCT ps;
    HBRUSH hBrush, hOldBrush;

    switch (msg)                  /* manipulador del mensaje */
    {
        case WM_PAINT:
           hDC = BeginPaint(hwnd, &ps);
           hBrush = CreateSolidBrush(RGB(240,0,0));
           hOldBrush = (HBRUSH)SelectObject(hDC, hBrush);
           switch(Comando) {
              case CM_CHORD:
                mChord(hDC);
                break;
              case CM_ELLIPSE:
                mEllipse(hDC);
                break;
              case CM_FILLRECT:
                mFillRect(hDC, hBrush);
                break;
              case CM_FRAMERECT:
                mFrameRect(hDC, hBrush);
                break;
              case CM_PIE:
                mPie(hDC);
                break;
              case CM_RECTANGLE:
                mRectangle(hDC);
                break;
              case CM_ROUNDRECT:
                mRoundRect(hDC);
                break;
              case CM_POLYGON:
                mPolygon(hDC);
                break;
              case CM_POLYPOLYGON:
                mPolyPolygon(hDC);
                break;
           }
           SelectObject(hDC, hOldBrush);
           DeleteObject(hBrush);
           EndPaint(hwnd, &ps);
           break;
        case WM_COMMAND:
           Comando = LOWORD(wParam);
           InvalidateRect(hwnd, NULL, TRUE);
           break;
        case WM_DESTROY:
           PostQuitMessage(0);    /* env�a un mensaje WM_QUIT a la cola de mensajes */
           break;
        default:                  /* para los mensajes de los que no nos ocupamos */
           return DefWindowProc(hwnd, msg, wParam, lParam);
    }
    return 0;
}

void mChord(HDC hDC)
{
   Chord(hDC, 10, 10, 210, 190, 210, 65, 10, 10);
}

void mEllipse(HDC hDC)
{
   Ellipse(hDC, 10, 10, 210, 190);
}

void mFillRect(HDC hDC, HBRUSH hBrush)
{
   RECT rect = {10,10,210,190};

   FillRect(hDC, &rect, hBrush);
}

void mFrameRect(HDC hDC, HBRUSH hBrush)
{
   RECT rect = {10,10,210,190};

   FrameRect(hDC, &rect, hBrush);
}

void mPie(HDC hDC)
{
   Pie(hDC, 10, 10, 210, 190, 210, 65, 10, 10);
}

void mPolygon(HDC hDC)
{
   POINT puntos[] = {10,10,50,10,75,25,95,45,210,190,100,150};
   Polygon(hDC, puntos, 6);
}

void mPolyPolygon(HDC hDC)
{
   POINT puntos[] = {10,10,60,10,60,60,35,60,35,30,
      85,60,110,30,130,30,160,60,130,90,110,90,
      60,120,110,180,60,180,
      130,120,160,140,190,120,190,180,160,160,130,180};
   INT cuenta[] = {5,6,3,6};

   PolyPolygon(hDC, puntos, cuenta, 4);
}

void mRectangle(HDC hDC)
{
   Rectangle(hDC, 10, 10, 210, 190);
}

void mRoundRect(HDC hDC)
{
   RoundRect(hDC, 10, 10, 210, 190, 25, 15);
}

