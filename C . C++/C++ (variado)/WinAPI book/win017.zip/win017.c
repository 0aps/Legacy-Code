#include <windows.h>
#include <string.h>
#include "ids.h"

WORD Comando; 
void mLineTo(HDC hDC);
void mArcTo(HDC hDC);
void mPolylineTo(HDC hDC);
void mPolyBezierTo(HDC hDC);
void mAngleArc(HDC hDC);
void mArc(HDC hDC);
void mPolyline(HDC hDC);
void mPolyBezier(HDC hDC);
void mLineDDA1(HDC hDC);
void mLineDDA2(HDC hDC);
void mPolyDraw(HDC hDC);
void mPolyPolyline(HDC hDC);

struct DatosDDA1{
   int cuenta;
   HDC hdc;
};

/*  Declaraci�n del procedimiento de ventana  */
LRESULT CALLBACK WindowProcedure (HWND, UINT, WPARAM, LPARAM);
VOID CALLBACK FuncionDDA1(int X, int Y, LPARAM lpData);
VOID CALLBACK FuncionDDA2(int X, int Y, LPARAM lpData);

int WINAPI WinMain (HINSTANCE hThisInstance,
                    HINSTANCE hPrevInstance,
                    LPSTR lpszArgument,
                    int nFunsterStil)
{
    HWND hwnd;               /* Manipulador de ventana */
    MSG mensaje;             /* Mensajes recibidos por la aplicaci�n */
    WNDCLASSEX wincl;        /* Estructura de datos para la clase de ventana */

    /* Estructura de la ventana */
    wincl.hInstance = hThisInstance;
    wincl.lpszClassName = "NUESTRA_CLASE";
    wincl.lpfnWndProc = WindowProcedure;      /* Esta funci�n es invocada por Windows */
    wincl.style = CS_DBLCLKS;                 /* Captura los doble-clicks */
    wincl.cbSize = sizeof (WNDCLASSEX);

    /* Usar icono y puntero por defector */
    wincl.hIcon = LoadIcon (NULL, IDI_APPLICATION);
    wincl.hIconSm = LoadIcon (NULL, IDI_APPLICATION);
    wincl.hCursor = LoadCursor (NULL, IDC_ARROW);
    wincl.lpszMenuName = "Menu";
    wincl.cbClsExtra = 0;                      /* Sin informaci�n adicional para la */
    wincl.cbWndExtra = 0;                      /* clase o la ventana */
    /* Usar el color de fondo por defecto para la ventana */
    wincl.hbrBackground = GetSysColorBrush(COLOR_BACKGROUND);

    /* Registrar la clase de ventana, si falla, salir del programa */
    if(!RegisterClassEx(&wincl)) return 0;
      
    /* La clase est� registrada, crear la ventana */
    hwnd = CreateWindowEx(
           0,                   /* Posibilidades de variaci�n */
           "NUESTRA_CLASE",     /* Nombre de la clase */
           "Ejemplo 017",       /* Texto del t�tulo */
           WS_OVERLAPPEDWINDOW, /* Tipo por defecto */
           CW_USEDEFAULT,       /* Windows decide la posici�n */
           CW_USEDEFAULT,       /* donde se coloca la ventana */
           544,                 /* Ancho */
           375,                 /* Alto en pixels */
           HWND_DESKTOP,        /* La ventana es hija del escritorio */
           NULL,                /* Sin men� */
           hThisInstance,       /* Manipulador de instancia */
           NULL                 /* No hay datos de creaci�n de ventana */
    );

    /* Mostrar la ventana */
    ShowWindow(hwnd, SW_SHOWDEFAULT);

    /* Bucle de mensajes, se ejecuta hasta que haya error o GetMessage devuelva FALSE */
    while(TRUE == GetMessage(&mensaje, NULL, 0, 0))
    {
        /* Traducir mensajes de teclas virtuales a mensajes de caracteres */
        TranslateMessage(&mensaje);
        /* Enviar mensaje al procedimiento de ventana */
        DispatchMessage(&mensaje);
    }

    /* Salir con valor de retorno */
    return mensaje.wParam;
}

LRESULT CALLBACK WindowProcedure(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
    HDC hDC;
    PAINTSTRUCT ps;

    switch (msg)                  /* manipulador del mensaje */
    {
        case WM_PAINT:
           hDC = BeginPaint(hwnd, &ps);
           switch(Comando) {
              case CM_LINETO:
                mLineTo(hDC);
                break;
              case CM_ARCTO:
                mArcTo(hDC);
                break;
              case CM_POLYLINETO:
                mPolylineTo(hDC);
                break;
              case CM_POLYBEZIERTO:
                mPolyBezierTo(hDC);
                break;
              case CM_ANGLEARC:
                mAngleArc(hDC);
                break;
              case CM_ARC:
                mArc(hDC);
                break;
              case CM_POLYLINE:
                mPolyline(hDC);
                break;
              case CM_POLYBEZIER:
                mPolyBezier(hDC);
                break;
              case CM_DDA1:
                mLineDDA1(hDC);
                break;
              case CM_DDA2:
                mLineDDA2(hDC);
                break;
              case CM_POLYDRAW:
                mPolyDraw(hDC);
                break;
              case CM_POLYPOLYLINE:
                mPolyPolyline(hDC);
                break;
           }
           EndPaint(hwnd, &ps);
           break;
        case WM_COMMAND:
           Comando = LOWORD(wParam);
           InvalidateRect(hwnd, NULL, TRUE);
           break;
        case WM_DESTROY:
           PostQuitMessage(0);    /* env�a un mensaje WM_QUIT a la cola de mensajes */
           break;
        default:                  /* para los mensajes de los que no nos ocupamos */
           return DefWindowProc(hwnd, msg, wParam, lParam);
    }
    return 0;
}

void mLineTo(HDC hDC)
{
   LineTo(hDC, 100, 100);
}

void mArcTo(HDC hDC)
{
   ArcTo(hDC, 20, 20, 120, 120, 120, 150, 110, 0);
}

void mPolylineTo(HDC hDC)
{
   POINT Puntos[6] = {20,20, 80,20, 20,80, 80,120, 120,20, 120,120};
   
   PolylineTo(hDC, Puntos, 6);
}

void mPolyBezierTo(HDC hDC)
{
   POINT Puntos[6] = {20,20, 80,20, 20,80, 80,120, 120,20, 120,120};
   
   PolyBezierTo(hDC, Puntos, 6);
}

void mAngleArc(HDC hDC)
{
   AngleArc(hDC, 90, 90, 85, 45, 270);
}

void mArc(HDC hDC)
{
   Arc(hDC, 20, 20, 120, 120, 120, 150, 110, 0);
}

void mPolyline(HDC hDC)
{
   POINT Puntos[6] = {20,20, 80,20, 20,80, 80,120, 120,20, 120,120};
   
   Polyline(hDC, Puntos, 6);
}

void mPolyBezier(HDC hDC)
{
   POINT Puntos[7] = {10,10, 20,20, 80,20, 20,80, 80,120, 120,20, 120,120};
   
   PolyBezier(hDC, Puntos, 7);
}

void mLineDDA1(HDC hDC)
{
   struct DatosDDA1 datos = {0, hDC};
   
   LineDDA(10,10, 240,180, FuncionDDA1, (LPARAM)&datos); 
}

void mLineDDA2(HDC hDC)
{
   struct DatosDDA1 datos = {0, hDC};

   LineDDA(10,10, 240,180, FuncionDDA2, (LPARAM)&datos); 
}

void mPolyDraw(HDC hDC)
{
   POINT Puntos[9] = {20,20, 80,20, 20,80, 80,120, 120,20, 120,120, 
      120,5, 60,115, 10,80};
   BYTE Tipos[9] = {PT_MOVETO, PT_LINETO, PT_LINETO, PT_BEZIERTO, PT_BEZIERTO,
      PT_BEZIERTO | PT_CLOSEFIGURE, PT_MOVETO, PT_LINETO, PT_LINETO};
   
   PolyDraw(hDC, Puntos, Tipos, 9);
}

void mPolyPolyline(HDC hDC)
{
   POINT Puntos[10] = {20,20, 80,20, 20,80, 80,120, 120,20, 120,120, 
      120,5, 60,115, 10,80, 30,50};
   DWORD PolyPuntos[3] = {3, 3, 4};
   
   PolyPolyline(hDC, Puntos, PolyPuntos, 3);
}

VOID CALLBACK FuncionDDA1(int X, int Y, LPARAM datos)
{
   struct DatosDDA1 *dato = (struct DatosDDA1 *)datos;
   
   // Funci�n que pinta l�neas con 10 pixels alternados rojos y verdes
   dato->cuenta++;
   if(dato->cuenta >= 20) dato->cuenta = 0; // Mantenemos cuenta entre 0 y 19
   if(dato->cuenta < 10) 
     SetPixel(dato->hdc, X, Y, RGB(0,255,0));
   else
     SetPixel(dato->hdc, X, Y, RGB(255,0,0));
}

VOID CALLBACK FuncionDDA2(int X, int Y, LPARAM datos)
{
   struct DatosDDA1 *dato = (struct DatosDDA1 *)datos;
   
   // Funci�n que pinta l�neas con cruces
   dato->cuenta++;
   if(dato->cuenta >= 10) dato->cuenta = 0; // Mantenemos cuenta entre 0 y 14
   if(dato->cuenta == 0) {
     SetPixel(dato->hdc, X, Y, RGB(0,255,0));
     MoveToEx(dato->hdc, X-2, Y, NULL);
     LineTo(dato->hdc, X+3, Y);
     MoveToEx(dato->hdc, X, Y-2, NULL);
     LineTo(dato->hdc, X, Y+3);
   }
}

