/* Identificadores */

/* Identificadores de comandos */
#define CM_DIALOGO 101

#define ID_GRUPO1	     101
#define ID_RADIOBUTTON1	 102
#define ID_RADIOBUTTON2  103
#define ID_RADIOBUTTON3  104
#define ID_GRUPO2        105
#define ID_RADIOBUTTON4  106
#define ID_RADIOBUTTON5  107
#define ID_RADIOBUTTON6  108

