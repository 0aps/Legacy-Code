//#define DI_FORM1     100
/*
#define SC_EDIT1    101
#define SC_EDIT2    102
#define SC_EDIT3    103
#define SC_BUTTON1  105
*/

#define C_EDIT1     110

#define NF_EDIT1    111
#define NF_EDIT2    112
#define NF_EDIT3    113
#define NF_CHECK1   114
#define NF_CHECK2   115
#define NF_CHECK3   116
#define NF_CHECK4   117
#define NF_STATIC1  118
#define NF_BUTTON1  119

const char EDIT[]="EDIT";
const char BUTTON[]="BUTTON";
const char STATIC[]="STATIC";
const char COMBOBOX[]="COMBOBOX";

const int USABLE_W=820;
const int USABLE_H=660;//660;

const HBRUSH NEGRO=CreateSolidBrush(RGB(0,0,0));
const HBRUSH BLANCO=CreateSolidBrush(RGB(255,255,255));
const HBRUSH DEFAULT=CreateSolidBrush(RGB(240,240,240));

struct
{
    char title[64], classname[64];
    HBRUSH bkg;
    BYTE r,g,b;
    DWORD exstyle;
    int x, y, w, h;
    //WS_EX_CLIENTEDGE
}initwindow;

struct Fuente
{
    Fuente *sig;
    int tam;
    int gros;
    bool italic;
    bool underline;
    bool strikeout;
    char fnombre[32];
    char nombre[32];
    bool used;
};

struct Control
{
    Control *sig;
    Fuente *fuente;
    const char *type;
    char title[64];
    int x, y, w, h;
    DWORD exstyle, style;
    HBRUSH bkg, color;
    BYTE rl,gl,bl;
    BYTE rf,gf,bf;
    bool color_l, color_f;
};
