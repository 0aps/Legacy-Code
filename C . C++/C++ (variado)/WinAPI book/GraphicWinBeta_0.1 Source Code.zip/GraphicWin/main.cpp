#include <windows.h>
#include <windowsx.h>
#include <stdio.h>
#include "Untitled1.h"

/*  Declare Windows procedure  */
LRESULT CALLBACK WindowProcedure (HWND, UINT, WPARAM, LPARAM);
void generarcodigo(HWND hwnd);
//BOOL CALLBACK sc_proc(HWND hDlg, UINT msg, WPARAM wParam, LPARAM lParam);
//BOOL CALLBACK nf_proc(HWND hDlg, UINT msg, WPARAM wParam, LPARAM lParam);

/*  Make the class name into a global variable  */
char szClassName[ ] = "Graphic Win";

HINSTANCE miinstance;
Control *selected=0;
Control *c_ini, *c_act;
Fuente *f_ini, *f_act;
int fcant=0;
//char *auxstrpt;

int WINAPI WinMain (HINSTANCE hThisInstance,
                     HINSTANCE hPrevInstance,
                     LPSTR lpszArgument,
                     int nCmdShow)
{
    HWND hwnd;               /* This is the handle for our window */
    MSG messages;            /* Here messages to the application are saved */
    WNDCLASSEX wincl;        /* Data structure for the windowclass */
    miinstance=hThisInstance;

    //DialogBox(hThisInstance, "NuevaFuente", NULL, nf_proc);
    //return 0;

    //Inicializar datos:
    initwindow.w=544;
    initwindow.h=375;
    initwindow.x=CW_USEDEFAULT;
    initwindow.y=CW_USEDEFAULT;
    initwindow.bkg=CreateSolidBrush(RGB(192,192,192));
    initwindow.r=initwindow.g=initwindow.b=192;
    initwindow.exstyle=0;
    strcpy(initwindow.classname, "windowsclass");
    strcpy(initwindow.title, "Mi Ventana");

    c_ini=c_act=new Control;
    c_act->sig=0;
    c_act->type=0;
    c_act->x=c_act->y=c_act->w=c_act->h=-1;

    f_ini=f_act=new Fuente;
    f_act->sig=0;


    /* The Window structure */
    wincl.hInstance = hThisInstance;
    wincl.lpszClassName = szClassName;
    wincl.lpfnWndProc = WindowProcedure;      /* This function is called by windows */
    wincl.style = CS_DBLCLKS;                 /* Catch double-clicks */
    wincl.cbSize = sizeof (WNDCLASSEX);

    /* Use default icon and mouse-pointer */
    wincl.hIcon = LoadIcon (hThisInstance, "MIICONO");
    wincl.hIconSm = LoadIcon (hThisInstance, "MIICONO");
    wincl.hCursor = LoadCursor (NULL, IDC_ARROW);
    wincl.lpszMenuName = NULL;                 /* No menu */
    wincl.cbClsExtra = 0;                      /* No extra bytes after the window class */
    wincl.cbWndExtra = 0;                      /* structure or the window instance */
    /* Use Windows's default colour as the background of the window */
    wincl.hbrBackground = CreateSolidBrush(RGB(240,240,240));

    /* Register the window class, and if it fails quit the program */
    if (!RegisterClassEx (&wincl))
        return 0;

    /* The class is registered, let's create the program*/
    hwnd = CreateWindowEx (
           0,                   /* Extended possibilites for variation */
           szClassName,         /* Classname */
           "C++ Graphic Win",       /* Title Text */
           WS_OVERLAPPEDWINDOW, /* default window */
           0,       /* Windows decides the position */
           0,       /* where the window ends up on the screen */
           922,                 /* The programs width */
           698,                 /* and height in pixels */
           HWND_DESKTOP,        /* The window is a child-window to desktop */
           NULL,                /* No menu */
           hThisInstance,       /* Program Instance handler */
           NULL                 /* No Window Creation data */
           );

    /* Make the window visible on the screen */
    ShowWindow (hwnd, nCmdShow);

    /* Run the message loop. It will run until GetMessage() returns 0 */
    while (GetMessage (&messages, NULL, 0, 0))
    {
        /* Translate virtual-key messages into character messages */
        TranslateMessage(&messages);
        /* Send message to WindowProcedure */
        DispatchMessage(&messages);
    }

    /* The program return-value is 0 - The value that PostQuitMessage() gave */
    return messages.wParam;
}
/*
BOOL CALLBACK sc_proc(HWND hdlg, UINT msg, WPARAM wParam, LPARAM lParam)
{
    switch (msg)
    {
        case WM_INITDIALOG:
            SendDlgItemMessage(hdlg, SC_EDIT1, EM_LIMITTEXT, 3, 0L);
            SendDlgItemMessage(hdlg, SC_EDIT2, EM_LIMITTEXT, 3, 0L);
            SendDlgItemMessage(hdlg, SC_EDIT3, EM_LIMITTEXT, 3, 0L);
            SetFocus(GetDlgItem(hdlg, SC_EDIT1));
            if(selected==0)
            {
                SetDlgItemInt(hdlg, SC_EDIT1, initwindow.r, false);
                SetDlgItemInt(hdlg, SC_EDIT2, initwindow.g, false);
                SetDlgItemInt(hdlg, SC_EDIT3, initwindow.b, false);
            }
            return FALSE;
        case WM_COMMAND:
        switch(LOWORD(wParam))
        {
            case SC_EDIT1:
                if(GetDlgItemInt(hdlg, SC_EDIT1, NULL, false)>255)
                    SetDlgItemInt(hdlg, SC_EDIT1, 255, false);
                break;
            case SC_EDIT2:
                if(GetDlgItemInt(hdlg, SC_EDIT2, NULL, false)>255)
                    SetDlgItemInt(hdlg, SC_EDIT2, 255, false);
                break;
            case SC_EDIT3:
                if(GetDlgItemInt(hdlg, SC_EDIT3, NULL, false)>255)
                    SetDlgItemInt(hdlg, SC_EDIT3, 255, false);
                break;
            case SC_BUTTON1:
                if(selected==0)
                {
                    initwindow.r=GetDlgItemInt(hdlg, SC_EDIT1, NULL, false);
                    initwindow.g=GetDlgItemInt(hdlg, SC_EDIT2, NULL, false);
                    initwindow.b=GetDlgItemInt(hdlg, SC_EDIT3, NULL, false);
                    initwindow.bkg=CreateSolidBrush(RGB(initwindow.r,initwindow.g,initwindow.b));
                    //refrescar(hwnd);
                }
                EndDialog(hdlg, FALSE);
                break;
        }
        return TRUE;
    }
    return FALSE;
}
*/

/*
BOOL CALLBACK vc_proc(HWND hdlg, UINT msg, WPARAM wParam, LPARAM lParam)
{
    switch (msg)
    {
        case WM_INITDIALOG:
            SetDlgItemText(hdlg, VC_EDIT1, auxstrpt);
            return FALSE;
        case WM_COMMAND:
            switch(LOWORD(wParam))
            {
            }
            return TRUE;
        case WM_DESTROY:
        case WM_CLOSE:
            EndDialog(hdlg, FALSE);
            return FALSE;
    }
    return FALSE;
}*/


BOOL CALLBACK c_proc(HWND hdlg, UINT msg, WPARAM wParam, LPARAM lParam)
{
    switch (msg)
    {
        /*case WM_INITDIALOG:
            return FALSE;*/
        case WM_COMMAND:
            switch(LOWORD(wParam))
            {
                case C_EDIT1:
                EndDialog(hdlg, FALSE);
            }
            return TRUE;
        case WM_DESTROY:
        case WM_CLOSE:
            EndDialog(hdlg, FALSE);
            return FALSE;
    }
    return FALSE;
}


BOOL CALLBACK nf_proc(HWND hdlg, UINT msg, WPARAM wParam, LPARAM lParam)
{
    static char fnombre[32];
    static bool fi, fu, fs;
    static int ftam, fgros;
    //bool exito=true;
    static HFONT hFont;
    switch (msg)
    {
        case WM_INITDIALOG:
            if(IsDlgButtonChecked(hdlg, NF_CHECK1) == BST_CHECKED) fi=true;
            else fi=false;
            if(IsDlgButtonChecked(hdlg, NF_CHECK2) == BST_CHECKED) fu=true;
            else fu=false;
            if(IsDlgButtonChecked(hdlg, NF_CHECK3) == BST_CHECKED) fs=true;
            else fs=false;
            if(IsDlgButtonChecked(hdlg, NF_CHECK4) == BST_CHECKED) fgros=FW_BOLD;
            else fgros=FW_THIN;

            ftam=GetDlgItemInt(hdlg, NF_EDIT3, NULL, false);
            GetDlgItemText(hdlg, NF_EDIT2, fnombre, 30);
            hFont = CreateFont(ftam, 0, 0, 0, fgros, fi, fu, fs,0, 0, 0, 0, VARIABLE_PITCH | FF_SWISS, "Helv");
            /*if(hFont)exito=true;
            else exito=false;*/
            SendMessage(GetDlgItem(hdlg, NF_STATIC1), WM_SETFONT, (WPARAM) hFont, true);
            return FALSE;
        case WM_COMMAND:
            switch(LOWORD(wParam))
            {
                case NF_EDIT2:
                case NF_EDIT3:
                case NF_CHECK1:
                case NF_CHECK2:
                case NF_CHECK3:
                case NF_CHECK4:
                    DeleteFont(hFont);
                    if(IsDlgButtonChecked(hdlg, NF_CHECK1) == BST_CHECKED) fi=true;
                    else fi=false;
                    if(IsDlgButtonChecked(hdlg, NF_CHECK2) == BST_CHECKED) fu=true;
                    else fu=false;
                    if(IsDlgButtonChecked(hdlg, NF_CHECK3) == BST_CHECKED) fs=true;
                    else fs=false;
                    if(IsDlgButtonChecked(hdlg, NF_CHECK4) == BST_CHECKED) fgros=FW_BOLD;
                    else fgros=FW_THIN;
                    ftam=GetDlgItemInt(hdlg, NF_EDIT3, NULL, false);
                    GetDlgItemText(hdlg, NF_EDIT2, fnombre, 30);
                    hFont = CreateFont(ftam, 0, 0, 0, fgros, fi, fu, fs,0, 0, 0, 0, VARIABLE_PITCH | FF_SWISS, "Helv");
                    /*if(hFont)exito=true;
                    else exito=false;*/
                    SendMessage(GetDlgItem(hdlg, NF_STATIC1), WM_SETFONT, (WPARAM) hFont, true);
                    break;
                case NF_BUTTON1:
                    //if(!exito)if(MessageBox(NULL, "Esta fuente puede no ser valida, �desea continuar?", "???", MB_ICONERROR | MB_YESNO)!=6)break;
                    if(IsDlgButtonChecked(hdlg, NF_CHECK1) == BST_CHECKED) fi=true;
                    else fi=false;
                    if(IsDlgButtonChecked(hdlg, NF_CHECK2) == BST_CHECKED) fu=true;
                    else fu=false;
                    if(IsDlgButtonChecked(hdlg, NF_CHECK3) == BST_CHECKED) fs=true;
                    else fs=false;
                    if(IsDlgButtonChecked(hdlg, NF_CHECK4) == BST_CHECKED) fgros=FW_BOLD;
                    else fgros=FW_THIN;
                    ftam=GetDlgItemInt(hdlg, NF_EDIT3, NULL, false);
                    GetDlgItemText(hdlg, NF_EDIT1, f_act->nombre, 30);
                    GetDlgItemText(hdlg, NF_EDIT2, f_act->fnombre, 30);
                    f_act->gros=fgros;
                    f_act->tam=ftam;
                    f_act->italic=fi;
                    f_act->strikeout=fs;
                    f_act->underline=fu;

                    f_act->sig=new Fuente;
                    f_act=f_act->sig;
                    f_act->sig=0;

                    /*if(exito)*/DeleteFont(hFont);
                    fcant++;
                    EndDialog(hdlg, FALSE);
                    break;
            }
            return TRUE;
    }
    return FALSE;
}


void hacerlinea(HDC hDC, int x1, int y1, int x2, int y2)
{
    MoveToEx(hDC, x1, y1, NULL);
    LineTo(hDC, x2, y2);
}

/*void clear(HWND hwnd)
{//solo hace falta la parte grafica
    HDC hdc = GetDC(hwnd);
    SelectObject(hdc, CreateSolidBrush(RGB(192,192,192)));
    Rectangle(hdc, -1, -1, 921, 691);
    ReleaseDC(hwnd, hdc);
}*/

void dibujar(HDC hdc)
{
    //HDC hdc = GetDC(hwnd);
    //hacerlinea(hdc, 0, 660, 820, 660);
    hacerlinea(hdc, USABLE_W+2, 0, USABLE_W+2, USABLE_H+2);

    SelectObject(hdc, initwindow.bkg);
    Rectangle(hdc, 0, 0, initwindow.w-15, initwindow.h-36);

    Control *i;
    //RECT rect;
    if(c_ini!=c_act)
    for(i=c_ini;i->sig!=0;i=i->sig)
    {
        if(i==selected)
        {
            //hacerlinea(hdc, i->x, i->y, i->x+i->w, i->y+i->h);
            SelectObject(hdc, DEFAULT);
            Rectangle(hdc, i->x-2, i->y-2, i->w+i->x+2, i->h+i->y+2);
        }

        if(i->type==BUTTON)
        {
            SelectObject(hdc, NEGRO);
            Rectangle(hdc, i->x, i->y, i->w+i->x, i->h+i->y);
        }
        else if(i->type==EDIT)
        {
            if(i->color_f) SelectObject(hdc, i->bkg);
            else SelectObject(hdc, BLANCO);
            Rectangle(hdc, i->x, i->y, i->w+i->x, i->h+i->y);

            if(i->color_l) SelectObject(hdc, i->color);
            else SelectObject(hdc, NEGRO);
            Rectangle(hdc, i->x+i->w/4, i->y+i->h/4, (i->w/4)*3+i->x, (i->h/4)*3+i->y);

        }
        else if(i->type==STATIC)
        {
            SelectObject(hdc, initwindow.bkg);
            Rectangle(hdc, i->x, i->y, i->w+i->x, i->h+i->y);
            /*rect.top=i->x;
            rect.left=i->y;
            rect.right=i->w+i->x;
            rect.bottom=i->h+i->y;
            SetRectEmpty(&rect);*/
        }
    }
    //ReleaseDC(hwnd, hdc);
}

void refrescar(HWND hwnd)
{
    HDC hdc = GetDC(hwnd);
    SelectObject(hdc, DEFAULT);
    Rectangle(hdc, -1, -1, USABLE_W+2, USABLE_H+2);
    //Rectangle(hdc, -1, -1, 920, 660);
    UpdateWindow(hwnd);
    dibujar(hdc);
    ReleaseDC(hwnd, hdc);
}



LRESULT CALLBACK WindowProcedure (HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
    char str[64];
    int aint;
    static bool check1, check2;
    switch (message)
    {
        case WM_CREATE:

            static HFONT hFont = CreateFont(8, 0, 0, 0, 100, 0, 0, 0,0, 0, 0, 0, VARIABLE_PITCH | FF_SWISS, "Helv");
            static HWND hwndCombo1 = CreateWindowEx(0,COMBOBOX, "Agregar Control", WS_CHILD|WS_VISIBLE|WS_TABSTOP|CBS_DROPDOWNLIST, 823, 0, 84, 100, hwnd, 0, miinstance, NULL);
            SendMessage(hwndCombo1, CB_ADDSTRING, 0, (LPARAM)"Form");
            SendMessage(hwndCombo1, CB_ADDSTRING, 0, (LPARAM)"Button");
            SendMessage(hwndCombo1, CB_ADDSTRING, 0, (LPARAM)"Edit");
            SendMessage(hwndCombo1, CB_ADDSTRING, 0, (LPARAM)"Static");
            SendMessage(hwndCombo1, CB_SELECTSTRING, (WPARAM)-1, (LPARAM)"Form");
            //SendMessage(hwndCombo1, CB_SELECTSTRING, (WPARAM)-1, (LPARAM)"a");
            //SendMessage(hwndCombo1, CB_SELECTSTRING, (WPARAM)-1, (LPARAM)"b");
            static HWND hwndButton3 = CreateWindowEx(WS_EX_CLIENTEDGE,BUTTON, "Generar Codigo", WS_CHILD|WS_VISIBLE, 823, 23, 84, 21, hwnd, 0, miinstance, NULL);
            //static HWND hwndButton5 = CreateWindowEx(WS_EX_CLIENTEDGE,BUTTON, "Vista Previa", WS_CHILD|WS_VISIBLE, 823, 42, 84, 21, hwnd, 0, miinstance, NULL);
            static HWND hwndButton4 = CreateWindowEx(WS_EX_CLIENTEDGE,BUTTON, "Creditos", WS_CHILD|WS_VISIBLE, 823, 42, 84, 21, hwnd, 0, miinstance, NULL);





            static HWND hwndButton1 = CreateWindowEx(0,BUTTON, "Color de Texto", BS_RADIOBUTTON | BS_PUSHLIKE | WS_CHILD | WS_VISIBLE | WS_TABSTOP, 823, 385, 83, 21, hwnd, 0, miinstance, NULL);
            static HWND hwndButton2 = CreateWindowEx(0,BUTTON, "Color de Fondo", BS_RADIOBUTTON | BS_PUSHLIKE | WS_CHILD | WS_VISIBLE | WS_TABSTOP, 823, 406, 83, 21, hwnd, 0, miinstance, NULL);


            static HWND hwndStatic6 = CreateWindowEx(0,STATIC, "Color: ", WS_CHILD|WS_VISIBLE|ES_CENTER, 823, 465, 83, 21, hwnd, 0, miinstance, NULL);
            static HWND hwndStatic7 = CreateWindowEx(0,STATIC, "Color de Fondo: ", WS_CHILD|WS_VISIBLE|ES_CENTER, 823, 465, 83, 21, hwnd, 0, miinstance, NULL);
            static HWND hwndEdit6 = CreateWindowEx(0,EDIT, "192", WS_CHILD|WS_VISIBLE|WS_TABSTOP|WS_BORDER|ES_NUMBER, 823, 480, 26, 18, hwnd, 0, miinstance, NULL);
            static HWND hwndEdit7 = CreateWindowEx(0,EDIT, "192", WS_CHILD|WS_VISIBLE|WS_TABSTOP|WS_BORDER|ES_NUMBER, 851, 480, 26, 18, hwnd, 0, miinstance, NULL);
            static HWND hwndEdit8 = CreateWindowEx(0,EDIT, "192", WS_CHILD|WS_VISIBLE|WS_TABSTOP|WS_BORDER|ES_NUMBER, 880, 480, 26, 18, hwnd, 0, miinstance, NULL);

            static HWND hwndStatic8 = CreateWindowEx(0,STATIC, "Color de Letra: ", WS_CHILD|WS_VISIBLE|ES_CENTER, 823, 430, 83, 21, hwnd, 0, miinstance, NULL);
            static HWND hwndEdit9 = CreateWindowEx(0,EDIT, "", WS_CHILD|WS_VISIBLE|WS_TABSTOP|WS_BORDER|ES_NUMBER, 823, 445, 26, 18, hwnd, 0, miinstance, NULL);
            static HWND hwndEdit10 = CreateWindowEx(0,EDIT, "", WS_CHILD|WS_VISIBLE|WS_TABSTOP|WS_BORDER|ES_NUMBER, 851, 445, 26, 18, hwnd, 0, miinstance, NULL);
            static HWND hwndEdit11 = CreateWindowEx(0,EDIT, "", WS_CHILD|WS_VISIBLE|WS_TABSTOP|WS_BORDER|ES_NUMBER, 880, 445, 26, 18, hwnd, 0, miinstance, NULL);


            static HWND hwndStatic9 = CreateWindowEx(0,STATIC, "Fuente: ", WS_CHILD|WS_VISIBLE|ES_CENTER, 823, 500, 83, 21, hwnd, 0, miinstance, NULL);
            static HWND hwndCombo2 = CreateWindowEx(0,COMBOBOX, "Fuente", WS_CHILD|WS_VISIBLE|WS_TABSTOP|CBS_DROPDOWNLIST, 823, 515, 84, 100, hwnd, 0, miinstance, NULL);
            SendMessage(hwndCombo2, CB_ADDSTRING, 0, (LPARAM)"Default");
            SendMessage(hwndCombo2, CB_ADDSTRING, 0, (LPARAM)"Nuevo");


            static HWND hwndStatic5 = CreateWindowEx(0,STATIC, "Titulo:", WS_CHILD|WS_VISIBLE|ES_CENTER, 823, 535, 83, 21, hwnd, 0, miinstance, NULL);
            static HWND hwndEdit5 = CreateWindowEx(0,EDIT, initwindow.title, WS_CHILD|WS_VISIBLE|WS_TABSTOP|WS_BORDER|ES_CENTER, 823, 550, 83, 18, hwnd, 0, miinstance, NULL);
            static HWND hwndEdit1 = CreateWindowEx(0,EDIT, "-1", WS_CHILD|WS_VISIBLE|WS_TABSTOP|WS_BORDER|ES_NUMBER, 852, 570, 32, 18, hwnd, 0, miinstance, NULL);
            static HWND hwndStatic1 = CreateWindowEx(0,STATIC, "X:", WS_CHILD|WS_VISIBLE, 834, 572, 12, 12, hwnd, 0, miinstance, NULL);
            static HWND hwndEdit2 = CreateWindowEx(0,EDIT, "-1", WS_CHILD|WS_VISIBLE|WS_TABSTOP|WS_BORDER|ES_NUMBER, 852, 590, 32, 18, hwnd, 0, miinstance, NULL);
            static HWND hwndStatic2 = CreateWindowEx(0,STATIC, "Y:", WS_CHILD|WS_VISIBLE, 834, 592, 12, 12, hwnd, 0, miinstance, NULL);
            static HWND hwndEdit3 = CreateWindowEx(0,EDIT, "544", WS_CHILD|WS_VISIBLE|WS_TABSTOP|WS_BORDER|ES_NUMBER, 852, 610, 32, 18, hwnd, 0, miinstance, NULL);
            static HWND hwndStatic3 = CreateWindowEx(0,STATIC, "W:", WS_CHILD|WS_VISIBLE, 834, 612, 14, 12, hwnd, 0, miinstance, NULL);
            static HWND hwndEdit4 = CreateWindowEx(0,EDIT, "375", WS_CHILD|WS_VISIBLE|WS_TABSTOP|WS_BORDER|ES_NUMBER, 852, 630, 32, 18, hwnd, 0, miinstance, NULL);
            static HWND hwndStatic4 = CreateWindowEx(0,STATIC, "H:", WS_CHILD|WS_VISIBLE, 834, 632, 12, 12, hwnd, 0, miinstance, NULL);


            SendMessage(hwndEdit1, WM_SETFONT, (WPARAM) hFont, true);
            SendMessage(hwndEdit2, WM_SETFONT, (WPARAM) hFont, true);
            SendMessage(hwndEdit3, WM_SETFONT, (WPARAM) hFont, true);
            SendMessage(hwndEdit4, WM_SETFONT, (WPARAM) hFont, true);
            SendMessage(hwndEdit5, WM_SETFONT, (WPARAM) hFont, true);
            SendMessage(hwndEdit6, WM_SETFONT, (WPARAM) hFont, true);
            SendMessage(hwndEdit7, WM_SETFONT, (WPARAM) hFont, true);
            SendMessage(hwndEdit8, WM_SETFONT, (WPARAM) hFont, true);
            SendMessage(hwndEdit9, WM_SETFONT, (WPARAM) hFont, true);
            SendMessage(hwndEdit10, WM_SETFONT, (WPARAM) hFont, true);
            SendMessage(hwndEdit11, WM_SETFONT, (WPARAM) hFont, true);
            SendMessage(hwndStatic1, WM_SETFONT, (WPARAM) hFont, true);
            SendMessage(hwndStatic2, WM_SETFONT, (WPARAM) hFont, true);
            SendMessage(hwndStatic3, WM_SETFONT, (WPARAM) hFont, true);
            SendMessage(hwndStatic4, WM_SETFONT, (WPARAM) hFont, true);
            SendMessage(hwndStatic5, WM_SETFONT, (WPARAM) hFont, true);
            SendMessage(hwndStatic6, WM_SETFONT, (WPARAM) hFont, true);
            SendMessage(hwndStatic7, WM_SETFONT, (WPARAM) hFont, true);
            SendMessage(hwndStatic8, WM_SETFONT, (WPARAM) hFont, true);
            SendMessage(hwndStatic9, WM_SETFONT, (WPARAM) hFont, true);
            SendMessage(hwndCombo1, WM_SETFONT, (WPARAM) hFont, true);
            SendMessage(hwndCombo2, WM_SETFONT, (WPARAM) hFont, true);
            SendMessage(hwndButton1, WM_SETFONT, (WPARAM) hFont, true);
            SendMessage(hwndButton2, WM_SETFONT, (WPARAM) hFont, true);
            SendMessage(hwndButton3, WM_SETFONT, (WPARAM) hFont, true);
            SendMessage(hwndButton4, WM_SETFONT, (WPARAM) hFont, true);
            EnableWindow(hwndEdit1, false);
            EnableWindow(hwndEdit2, false);
            EnableWindow(hwndCombo2, false);
            ShowWindow(hwndEdit9, SW_HIDE);
            ShowWindow(hwndEdit10, SW_HIDE);
            ShowWindow(hwndEdit11, SW_HIDE);
            ShowWindow(hwndStatic7, SW_HIDE);
            ShowWindow(hwndStatic8, SW_HIDE);
            ShowWindow(hwndButton1, SW_HIDE);
            ShowWindow(hwndButton2, SW_HIDE);
            break;
        case WM_PAINT:
            PAINTSTRUCT ps;
            HDC hdc;
            hdc = BeginPaint(hwnd, &ps);
            dibujar(hdc);
            EndPaint(hwnd, &ps);
            break;
        case WM_COMMAND:
            if(lParam==(LPARAM)hwndCombo1 && wParam==65536)
            {
                int cual;
                //SendMessage(hwndCombo1, CBN_SELENDCANCEL, 0, 0);
                cual=SendMessage(hwndCombo1, CB_GETCURSEL, 0, 0);
                SendMessage(hwndCombo1, CB_SELECTSTRING, (WPARAM)-1, (LPARAM)"Form");
                SendMessage(hwndCombo2, CB_SELECTSTRING, (WPARAM)-1, (LPARAM)"Default");
                if(cual==0)
                {
                    selected=0;
                    strcpy(str, "-1");
                    SetWindowText(hwndEdit1, str);
                    SetWindowText(hwndEdit2, str);

                    itoa(initwindow.w, str, 10);
                    SetWindowText(hwndEdit3, str);
                    itoa(initwindow.h, str, 10);
                    SetWindowText(hwndEdit4, str);

                    SetWindowText(hwndEdit5, initwindow.title);

                    itoa(initwindow.r, str,10);
                    SetWindowText(hwndEdit6, str);
                    itoa(initwindow.g, str,10);
                    SetWindowText(hwndEdit7, str);
                    itoa(initwindow.b, str,10);
                    SetWindowText(hwndEdit8, str);


                    EnableWindow(hwndEdit1, false);
                    EnableWindow(hwndEdit2, false);
                    EnableWindow(hwndEdit6, true);
                    EnableWindow(hwndEdit7, true);
                    EnableWindow(hwndEdit8, true);
                    EnableWindow(hwndCombo2, false);
                    ShowWindow(hwndEdit6, SW_SHOW);
                    ShowWindow(hwndEdit7, SW_SHOW);
                    ShowWindow(hwndEdit8, SW_SHOW);
                    ShowWindow(hwndEdit9, SW_HIDE);
                    ShowWindow(hwndEdit10, SW_HIDE);
                    ShowWindow(hwndEdit11, SW_HIDE);
                    ShowWindow(hwndStatic7, SW_HIDE);
                    ShowWindow(hwndStatic8, SW_HIDE);
                    ShowWindow(hwndButton1, SW_HIDE);
                    ShowWindow(hwndButton2, SW_HIDE);
                }
                else if(cual==1)
                {
                    selected=c_act;
                    c_act->x=0;
                    c_act->y=0;
                    c_act->w=80;
                    c_act->h=20;
                    strcpy(c_act->title, "Mi Botton");
                    c_act->type=BUTTON;
                    c_act->style=WS_CHILD|WS_VISIBLE|WS_TABSTOP|WS_BORDER;
                    c_act->exstyle=0;
                    c_act->fuente=0;

                    c_act->sig=new Control;
                    c_act=c_act->sig;
                    c_act->sig=0;
                    c_act->type=0;
                    c_act->x=c_act->y=c_act->w=c_act->h=-1;


                    SetWindowText(hwndEdit1, "0");
                    SetWindowText(hwndEdit2, "0");
                    SetWindowText(hwndEdit3, "80");
                    SetWindowText(hwndEdit4, "20");
                    SetWindowText(hwndEdit5, "Mi Boton");

                    EnableWindow(hwndEdit1, true);
                    EnableWindow(hwndEdit2, true);
                    EnableWindow(hwndCombo2, true);
                    ShowWindow(hwndEdit6, SW_HIDE);
                    ShowWindow(hwndEdit7, SW_HIDE);
                    ShowWindow(hwndEdit8, SW_HIDE);
                    ShowWindow(hwndEdit9, SW_HIDE);
                    ShowWindow(hwndEdit10, SW_HIDE);
                    ShowWindow(hwndEdit11, SW_HIDE);
                    ShowWindow(hwndStatic6, SW_HIDE);
                    ShowWindow(hwndStatic7, SW_HIDE);
                    ShowWindow(hwndStatic8, SW_HIDE);
                    ShowWindow(hwndButton1, SW_HIDE);
                    ShowWindow(hwndButton2, SW_HIDE);
                }
                else if(cual==2)
                {
                    selected=c_act;
                    c_act->x=0;
                    c_act->y=0;
                    c_act->w=80;
                    c_act->h=20;
                    strcpy(c_act->title, "Mi Txtbox");
                    c_act->type=EDIT;
                    c_act->style=WS_CHILD|WS_VISIBLE|WS_TABSTOP;
                    c_act->exstyle=0;
                    c_act->color_l=false;
                    c_act->color_f=false;
                    c_act->rl=0;
                    c_act->gl=0;
                    c_act->bl=0;
                    c_act->rf=255;
                    c_act->gf=255;
                    c_act->bf=255;
                    c_act->bkg=BLANCO;
                    c_act->color=NEGRO;
                    c_act->fuente=0;

                    c_act->sig=new Control;
                    c_act=c_act->sig;
                    c_act->sig=0;
                    c_act->type=0;


                    check1=check2=false;
                    SetWindowText(hwndEdit1, "0");
                    SetWindowText(hwndEdit2, "0");
                    SetWindowText(hwndEdit3, "80");
                    SetWindowText(hwndEdit4, "20");
                    SetWindowText(hwndEdit5, "Mi Txtbox");
                    SetWindowText(hwndEdit6, itoa(selected->rf, str, 10));
                    SetWindowText(hwndEdit7, itoa(selected->gf, str, 10));
                    SetWindowText(hwndEdit8, itoa(selected->bf, str, 10));
                    SetWindowText(hwndEdit9, itoa(selected->rl, str, 10));
                    SetWindowText(hwndEdit10, itoa(selected->gl, str, 10));
                    SetWindowText(hwndEdit11, itoa(selected->bl, str, 10));

                    SendMessage(hwndButton1, BM_SETCHECK, (WPARAM)BST_UNCHECKED, 0);
                    SendMessage(hwndButton2, BM_SETCHECK, (WPARAM)BST_UNCHECKED, 0);
                    EnableWindow(hwndEdit1, true);
                    EnableWindow(hwndEdit2, true);
                    EnableWindow(hwndEdit6, false);
                    EnableWindow(hwndEdit7, false);
                    EnableWindow(hwndEdit8, false);
                    EnableWindow(hwndEdit9, false);
                    EnableWindow(hwndEdit10, false);
                    EnableWindow(hwndEdit11, false);
                    EnableWindow(hwndCombo2, true);
                    ShowWindow(hwndEdit6, SW_SHOW);
                    ShowWindow(hwndEdit7, SW_SHOW);
                    ShowWindow(hwndEdit8, SW_SHOW);
                    ShowWindow(hwndEdit9, SW_SHOW);
                    ShowWindow(hwndEdit10, SW_SHOW);
                    ShowWindow(hwndEdit11, SW_SHOW);
                    ShowWindow(hwndStatic6, SW_HIDE);
                    ShowWindow(hwndStatic7, SW_SHOW);
                    ShowWindow(hwndStatic8, SW_SHOW);
                    ShowWindow(hwndButton1, SW_SHOW);
                    ShowWindow(hwndButton2, SW_SHOW);
                }
                else if(cual==3)
                {
                    selected=c_act;
                    c_act->x=0;
                    c_act->y=0;
                    c_act->w=80;
                    c_act->h=20;
                    strcpy(c_act->title, "Mi Texto");
                    c_act->type=STATIC;
                    c_act->style=WS_CHILD|WS_VISIBLE;
                    c_act->exstyle=0;
                    c_act->fuente=0;

                    c_act->sig=new Control;
                    c_act=c_act->sig;
                    c_act->sig=0;
                    c_act->type=0;

                    SetWindowText(hwndEdit1, "0");
                    SetWindowText(hwndEdit2, "0");
                    SetWindowText(hwndEdit3, "80");
                    SetWindowText(hwndEdit4, "20");
                    SetWindowText(hwndEdit5, "Mi Texto");

                    EnableWindow(hwndEdit1, true);
                    EnableWindow(hwndEdit2, true);
                    EnableWindow(hwndCombo2, true);
                    ShowWindow(hwndEdit6, SW_HIDE);
                    ShowWindow(hwndEdit7, SW_HIDE);
                    ShowWindow(hwndEdit8, SW_HIDE);
                    ShowWindow(hwndEdit9, SW_HIDE);
                    ShowWindow(hwndEdit10, SW_HIDE);
                    ShowWindow(hwndEdit11, SW_HIDE);
                    ShowWindow(hwndStatic6, SW_HIDE);
                    ShowWindow(hwndStatic7, SW_HIDE);
                    ShowWindow(hwndStatic8, SW_HIDE);
                    ShowWindow(hwndButton1, SW_HIDE);
                    ShowWindow(hwndButton2, SW_HIDE);
                }
                refrescar(hwnd);
                SetFocus(hwnd);
            }
            else if(lParam==(LPARAM)hwndCombo2 && wParam==65536 && selected!=0)
            {
                int cual;
                Fuente *i, *ant=0;
                cual=SendMessage(hwndCombo2, CB_GETCURSEL, 0, 0);
                if(cual==0) selected->fuente=0;
                else if(cual==1)
                {
                    DialogBox(miinstance, "NuevaFuente", NULL, nf_proc);
                    //SendMessage(hwndCombo2, CB_RESETCONTENT, 0, 0);
                    for(i=f_ini;i->sig!=0;i=i->sig)ant=i;
                    if(selected)selected->fuente=ant;
                    SendMessage(hwndCombo2, CB_ADDSTRING, 0, (LPARAM)ant->nombre);
                    SendMessage(hwndCombo2, CB_SELECTSTRING, (WPARAM)-1, (LPARAM)ant->nombre);
                }
                else
                {
                    for(i=f_ini;i->sig!=0;i=i->sig)
                    {
                        cual--;
                        if(cual==1) if(selected)
                        {
                            selected->fuente=i;
                        }
                        else break;
                    }
                }
            }
            else if(lParam==(LPARAM)hwndEdit1 && wParam==50331648)
            {
                if(selected!=0)
                {
                    GetWindowText(hwndEdit1, str, 64);
                    selected->x=atoi(str);
                    if(selected->x+selected->w>USABLE_W)
                    {
                        selected->x=USABLE_W-selected->w;
                        itoa(selected->x, str, 10);
                        SetWindowText(hwndEdit1, str);
                    }
                    refrescar(hwnd);
                }
            }
            else if(lParam==(LPARAM)hwndEdit2 && wParam==50331648)
            {
                if(selected!=0)
                {
                    GetWindowText(hwndEdit2, str, 64);
                    selected->y=atoi(str);
                    if(selected->y+selected->h>USABLE_H)
                    {
                        selected->y=USABLE_H-selected->h;
                        itoa(selected->y, str, 10);
                        SetWindowText(hwndEdit2, str);
                    }
                    refrescar(hwnd);
                }
            }
            else if(lParam==(LPARAM)hwndEdit3 && wParam==50331648)
            {
                if(selected==0)
                {
                    GetWindowText(hwndEdit3, str, 64);
                    initwindow.w=atoi(str);
                    if(initwindow.w>USABLE_W)
                    {
                        initwindow.w=USABLE_W;
                        itoa(initwindow.w, str, 10);
                        SetWindowText(hwndEdit3, str);
                    }
                    refrescar(hwnd);
                }
                else
                {
                    GetWindowText(hwndEdit3, str, 64);
                    selected->w=atoi(str);
                    if(selected->w+selected->x>USABLE_W)
                    {
                        selected->w=USABLE_W-selected->x;
                        itoa(selected->w, str, 10);
                        SetWindowText(hwndEdit3, str);
                    }
                    refrescar(hwnd);
                }
            }
            else if(lParam==(LPARAM)hwndEdit4 && wParam==50331648)
            {
                if(selected==0)
                {
                    GetWindowText(hwndEdit4, str, 64);
                    initwindow.h=atoi(str);
                    if(initwindow.h>USABLE_H)
                    {
                        initwindow.h=USABLE_H;
                        itoa(initwindow.h, str, 10);
                        SetWindowText(hwndEdit4, str);
                    }
                    refrescar(hwnd);
                }
                else
                {
                    GetWindowText(hwndEdit4, str, 64);
                    selected->h=atoi(str);
                    if(selected->h+selected->y>USABLE_H)
                    {
                        selected->h=USABLE_H-selected->y;
                        itoa(selected->h, str, 10);
                        SetWindowText(hwndEdit4, str);
                    }
                    refrescar(hwnd);
                }
            }
            else if(lParam==(LPARAM)hwndEdit5 && wParam==50331648)
            {
                if(selected==0)
                {
                    GetWindowText(hwndEdit5, str, 64);
                    strcpy(initwindow.title, str);
                }
                else
                {
                    GetWindowText(hwndEdit5, str, 64);
                    strcpy(selected->title, str);
                }
            }
            else if(lParam==(LPARAM)hwndEdit6 && wParam==50331648)
            {

                GetWindowText(hwndEdit6, str, 64);
                aint=atoi(str);
                if(aint>255)
                {
                    aint=255;
                    itoa(aint, str, 10);
                    SetWindowText(hwndEdit6, str);
                }

                if(selected==0)
                {
                    initwindow.r=aint;
                    initwindow.bkg=CreateSolidBrush(RGB(initwindow.r,initwindow.g,initwindow.b));
                    refrescar(hwnd);
                }
                else
                {
                    selected->rf=aint;
                    selected->bkg=CreateSolidBrush(RGB(selected->rf,selected->gf,selected->bf));
                    refrescar(hwnd);
                }
            }
            else if(lParam==(LPARAM)hwndEdit7 && wParam==50331648)
            {

                GetWindowText(hwndEdit7, str, 64);
                aint=atoi(str);
                if(aint>255)
                {
                    aint=255;
                    itoa(aint, str, 10);
                    SetWindowText(hwndEdit7, str);
                }

                if(selected==0)
                {
                    initwindow.g=aint;
                    initwindow.bkg=CreateSolidBrush(RGB(initwindow.r,initwindow.g,initwindow.b));
                    refrescar(hwnd);
                }
                else
                {
                    selected->gf=aint;
                    selected->bkg=CreateSolidBrush(RGB(selected->rf,selected->gf,selected->bf));
                    refrescar(hwnd);
                }
            }
            else if(lParam==(LPARAM)hwndEdit8 && wParam==50331648)
            {
                GetWindowText(hwndEdit8, str, 64);
                aint=atoi(str);
                if(aint>255)
                {
                    aint=255;
                    itoa(aint, str, 10);
                    SetWindowText(hwndEdit8, str);
                }

                if(selected==0)
                {
                    initwindow.b=aint;
                    initwindow.bkg=CreateSolidBrush(RGB(initwindow.r,initwindow.g,initwindow.b));
                    refrescar(hwnd);
                }
                else
                {
                    selected->bf=aint;
                    selected->bkg=CreateSolidBrush(RGB(selected->rf,selected->gf,selected->bf));
                    refrescar(hwnd);
                }
            }
            else if(lParam==(LPARAM)hwndEdit9 && wParam==50331648)
            {
                GetWindowText(hwndEdit9, str, 64);
                aint=atoi(str);
                if(aint>255)
                {
                    aint=255;
                    itoa(aint, str, 10);
                    SetWindowText(hwndEdit9, str);
                }

                if(selected!=0)
                {
                    selected->rl=aint;
                    selected->color=CreateSolidBrush(RGB(selected->rl,selected->gl,selected->bl));
                    refrescar(hwnd);
                }
            }
            else if(lParam==(LPARAM)hwndEdit10 && wParam==50331648)
            {
                GetWindowText(hwndEdit10, str, 64);
                aint=atoi(str);
                if(aint>255)
                {
                    aint=255;
                    itoa(aint, str, 10);
                    SetWindowText(hwndEdit10, str);
                }

                if(selected!=0)
                {
                    selected->gl=aint;
                    selected->color=CreateSolidBrush(RGB(selected->rl,selected->gl,selected->bl));
                    refrescar(hwnd);
                }
            }
            else if(lParam==(LPARAM)hwndEdit11 && wParam==50331648)
            {
                GetWindowText(hwndEdit11, str, 64);
                aint=atoi(str);
                if(aint>255)
                {
                    aint=255;
                    itoa(aint, str, 10);
                    SetWindowText(hwndEdit11, str);
                }

                if(selected!=0)
                {
                    selected->bl=aint;
                    selected->color=CreateSolidBrush(RGB(selected->rl,selected->gl,selected->bl));
                    refrescar(hwnd);
                }
            }
            else if(lParam==(LPARAM)hwndButton1 && selected)
            {
                if(check1)
                {
                    SendMessage(hwndButton1, BM_SETCHECK, (WPARAM)BST_UNCHECKED, 0);
                    check1=false;
                    EnableWindow(hwndEdit9, false);
                    EnableWindow(hwndEdit10, false);
                    EnableWindow(hwndEdit11, false);
                    selected->color_l=false;
                }
                else
                {
                    SendMessage(hwndButton1, BM_SETCHECK, (WPARAM)BST_CHECKED, 0);
                    check1=true;
                    EnableWindow(hwndEdit9, true);
                    EnableWindow(hwndEdit10, true);
                    EnableWindow(hwndEdit11, true);
                    selected->color_l=true;
                }
                SetFocus(hwnd);
            }
            else if(lParam==(LPARAM)hwndButton2 && selected)
            {
                if(check2)
                {
                    SendMessage(hwndButton2, BM_SETCHECK, (WPARAM)BST_UNCHECKED, 0);
                    check2=false;
                    EnableWindow(hwndEdit6, false);
                    EnableWindow(hwndEdit7, false);
                    EnableWindow(hwndEdit8, false);
                    selected->color_f=false;
                }
                else
                {
                    SendMessage(hwndButton2, BM_SETCHECK, (WPARAM)BST_CHECKED, 0);
                    check2=true;
                    EnableWindow(hwndEdit6, true);
                    EnableWindow(hwndEdit7, true);
                    EnableWindow(hwndEdit8, true);
                    selected->color_f=true;
                }
                SetFocus(hwnd);
            }
            else if(lParam==(LPARAM)hwndButton3)
            {
                SetFocus(hwnd);
                generarcodigo(hwnd);
            }
            else if(lParam==(LPARAM)hwndButton4)
            {
                SetFocus(hwnd);
                DialogBox(miinstance, "Creditos", hwnd, c_proc);
            }
            break;
        case WM_LBUTTONDOWN:
            int mousex=GET_X_LPARAM(lParam), mousey=GET_Y_LPARAM(lParam);
            Control *i;
            for(i=c_ini;i->sig!=0;i=i->sig)
            {
                if(mousex>i->x && mousex<i->x+i->w && mousey>i->y && mousey<i->y+i->h)
                {
                    if(wParam & MK_CONTROL)
                    {
                        if(MessageBox(hwnd, "Borrar el Control ?", "?", MB_YESNO | MB_ICONWARNING)!=6) break;
                        Control *last=0, *next, *j;
                        for(j=c_ini;j->sig!=0;j=j->sig)
                        {
                            if(j==i)break;
                            last=j;
                        }
                        next=i->sig;
                        delete i;
                        if(last!=0)last->sig=next;
                        else
                        {
                            c_ini=next;
                        }
                        selected=0;

                        strcpy(str, "-1");
                        SetWindowText(hwndEdit1, str);
                        SetWindowText(hwndEdit2, str);
                        itoa(initwindow.w, str, 10);
                        SetWindowText(hwndEdit3, str);
                        itoa(initwindow.h, str, 10);
                        SetWindowText(hwndEdit4, str);

                        SetWindowText(hwndEdit5, initwindow.title);

                        itoa(initwindow.r, str,10);
                        SetWindowText(hwndEdit6, str);
                        itoa(initwindow.g, str,10);
                        SetWindowText(hwndEdit7, str);
                        itoa(initwindow.b, str,10);
                        SetWindowText(hwndEdit8, str);

                        EnableWindow(hwndEdit1, false);
                        EnableWindow(hwndEdit2, false);
                        EnableWindow(hwndEdit6, true);
                        EnableWindow(hwndEdit7, true);
                        EnableWindow(hwndEdit8, true);
                        EnableWindow(hwndCombo2, false);
                        ShowWindow(hwndEdit6, SW_SHOW);
                        ShowWindow(hwndEdit7, SW_SHOW);
                        ShowWindow(hwndEdit8, SW_SHOW);
                        ShowWindow(hwndEdit9, SW_HIDE);
                        ShowWindow(hwndEdit10, SW_HIDE);
                        ShowWindow(hwndEdit11, SW_HIDE);
                        ShowWindow(hwndStatic7, SW_HIDE);
                        ShowWindow(hwndStatic8, SW_HIDE);
                        ShowWindow(hwndButton1, SW_HIDE);
                        ShowWindow(hwndButton2, SW_HIDE);

                        refrescar(hwnd);
                        break;
                    }
                    selected=i;
                    SetWindowText(hwndEdit1, itoa(i->x, str, 10));
                    SetWindowText(hwndEdit2, itoa(i->y, str, 10));
                    SetWindowText(hwndEdit3, itoa(i->w, str, 10));
                    SetWindowText(hwndEdit4, itoa(i->h, str, 10));
                    SetWindowText(hwndEdit5, i->title);
                    SetWindowText(hwndEdit6, itoa(i->rf, str, 10));
                    SetWindowText(hwndEdit7, itoa(i->gf, str, 10));
                    SetWindowText(hwndEdit8, itoa(i->bf, str, 10));
                    SetWindowText(hwndEdit9, itoa(i->rl, str, 10));
                    SetWindowText(hwndEdit10, itoa(i->gl, str, 10));
                    SetWindowText(hwndEdit11, itoa(i->bl, str, 10));

                    if(i->fuente!=0)SendMessage(hwndCombo2, CB_SELECTSTRING, (WPARAM)-1, (LPARAM)(i->fuente)->nombre);
                    else SendMessage(hwndCombo2, CB_SELECTSTRING, (WPARAM)-1, (LPARAM)"Default");

                    if(i->type==BUTTON)
                    {
                        EnableWindow(hwndEdit1, true);
                        EnableWindow(hwndEdit2, true);
                        EnableWindow(hwndCombo2, true);
                        ShowWindow(hwndEdit6, SW_HIDE);
                        ShowWindow(hwndEdit7, SW_HIDE);
                        ShowWindow(hwndEdit8, SW_HIDE);
                        ShowWindow(hwndEdit9, SW_HIDE);
                        ShowWindow(hwndEdit10, SW_HIDE);
                        ShowWindow(hwndEdit11, SW_HIDE);
                        ShowWindow(hwndStatic6, SW_HIDE);
                        ShowWindow(hwndStatic7, SW_HIDE);
                        ShowWindow(hwndStatic8, SW_HIDE);
                        ShowWindow(hwndButton1, SW_HIDE);
                        ShowWindow(hwndButton2, SW_HIDE);
                    }
                    else if(i->type==EDIT)
                    {
                        EnableWindow(hwndEdit1, true);
                        EnableWindow(hwndEdit2, true);
                        EnableWindow(hwndCombo2, true);
                        ShowWindow(hwndEdit6, SW_SHOW);
                        ShowWindow(hwndEdit7, SW_SHOW);
                        ShowWindow(hwndEdit8, SW_SHOW);
                        ShowWindow(hwndEdit9, SW_SHOW);
                        ShowWindow(hwndEdit10, SW_SHOW);
                        ShowWindow(hwndEdit11, SW_SHOW);
                        ShowWindow(hwndStatic6, SW_HIDE);
                        ShowWindow(hwndStatic7, SW_SHOW);
                        ShowWindow(hwndStatic8, SW_SHOW);
                        ShowWindow(hwndButton1, SW_SHOW);
                        ShowWindow(hwndButton2, SW_SHOW);
                        if(i->color_l)
                        {
                            SendMessage(hwndButton1, BM_SETCHECK, (WPARAM)BST_CHECKED, 0);
                            EnableWindow(hwndEdit9, true);
                            EnableWindow(hwndEdit10, true);
                            EnableWindow(hwndEdit11, true);
                        }
                        else
                        {
                            SendMessage(hwndButton1, BM_SETCHECK, (WPARAM)BST_UNCHECKED, 0);
                            EnableWindow(hwndEdit9, false);
                            EnableWindow(hwndEdit10, false);
                            EnableWindow(hwndEdit11, false);
                        }

                        if(i->color_f)
                        {
                            SendMessage(hwndButton2, BM_SETCHECK, (WPARAM)BST_CHECKED, 0);
                            EnableWindow(hwndEdit6, true);
                            EnableWindow(hwndEdit7, true);
                            EnableWindow(hwndEdit8, true);
                        }
                        else
                        {
                            SendMessage(hwndButton2, BM_SETCHECK, (WPARAM)BST_UNCHECKED, 0);
                            EnableWindow(hwndEdit6, false);
                            EnableWindow(hwndEdit7, false);
                            EnableWindow(hwndEdit8, false);
                        }
                    }
                    else if(i->type==STATIC)
                    {
                        EnableWindow(hwndEdit1, true);
                        EnableWindow(hwndEdit2, true);
                        EnableWindow(hwndCombo2, true);
                        ShowWindow(hwndEdit6, SW_HIDE);
                        ShowWindow(hwndEdit7, SW_HIDE);
                        ShowWindow(hwndEdit8, SW_HIDE);
                        ShowWindow(hwndEdit9, SW_HIDE);
                        ShowWindow(hwndEdit10, SW_HIDE);
                        ShowWindow(hwndEdit11, SW_HIDE);
                        ShowWindow(hwndStatic6, SW_HIDE);
                        ShowWindow(hwndStatic7, SW_HIDE);
                        ShowWindow(hwndStatic8, SW_HIDE);
                        ShowWindow(hwndButton1, SW_HIDE);
                        ShowWindow(hwndButton2, SW_HIDE);
                    }
                    break;
                }
            }
            SetFocus(hwnd);
            break;
        case WM_KEYDOWN:
            if(selected!=0)
            {
                switch(wParam)
                {
                    case 38:
                        selected->y-=5;
                        if(selected->y<0)selected->y=0;
                        SetWindowText(hwndEdit2, itoa(selected->y, str, 10));
                        refrescar(hwnd);
                        break;
                    case 40:
                        selected->y+=5;
                        if(selected->y>USABLE_H-selected->h)selected->y=USABLE_H-selected->h;
                        SetWindowText(hwndEdit2, itoa(selected->y, str, 10));
                        refrescar(hwnd);
                        break;
                    case 37:
                        selected->x-=5;
                        if(selected->x<0)selected->x=0;
                        SetWindowText(hwndEdit1, itoa(selected->x, str, 10));
                        refrescar(hwnd);
                        break;
                    case 39:
                        selected->x+=5;
                        if(selected->x>USABLE_W-selected->w-4)selected->x=USABLE_W-selected->w-4;
                        SetWindowText(hwndEdit1, itoa(selected->x, str, 10));
                        refrescar(hwnd);
                        break;
                }
            }

            break;
        case WM_DESTROY:
            DeleteObject(hFont);
            PostQuitMessage (0);       /* send a WM_QUIT to the message queue */
            break;
        default:                      /* for messages that we don't deal with */
            return DefWindowProc (hwnd, message, wParam, lParam);
    }

    return 0;
}


void generarcodigo(HWND hwnd)
{
    char *buffer;
    HGLOBAL hgbuffer;
    hgbuffer=GlobalAlloc(/*GMEM_DDESHARE | */GMEM_MOVEABLE, 65536);
    buffer = (char*)GlobalLock(hgbuffer);

    char linea[1024];
    char aux[2][128];
    int bcount=1, ecount=1, scount=1, acount=0, pcount=1, fcount=1;
    bool primero=true;
    Control *i;
    Fuente *j;

    for(j=f_ini;j->sig!=0;j=j->sig) j->used=false;
    for(i=c_ini;i->sig!=0;i=i->sig)if(i->fuente)(i->fuente)->used=true;

    strcpy(buffer, "");
    strcat(buffer,
    "#include <windows.h>\n\n"
    "LRESULT CALLBACK WindowProcedure (HWND, UINT, WPARAM, LPARAM);\n"
    "char szClassName[ ] = \"");
    strcat(buffer, initwindow.classname);
    strcat(buffer,
    "\";\n"
    "HINSTANCE miinstance;\n\n"
    "int WINAPI WinMain (HINSTANCE hThisInstance, HINSTANCE hPrevInstance, LPSTR lpszArgument, int nCmdShow)\n"
    "{\n"
    "    HWND hwnd;\n"
    "    MSG messages;\n"
    "    WNDCLASSEX wincl;\n"
    "    miinstance=hThisInstance;\n\n"
    "    wincl.hInstance = hThisInstance;\n"
    "    wincl.lpszClassName = szClassName;\n"
    "    wincl.lpfnWndProc = WindowProcedure;\n"
    "    wincl.style = CS_DBLCLKS;\n"
    "    wincl.cbSize = sizeof (WNDCLASSEX);\n\n"
    "    wincl.hIcon = LoadIcon (NULL, IDI_APPLICATION);\n"
    "    wincl.hIconSm = LoadIcon (NULL, IDI_APPLICATION);\n"
    "    wincl.hCursor = LoadCursor (NULL, IDC_ARROW);\n"
    "    wincl.lpszMenuName = NULL;\n"
    "    wincl.cbClsExtra = 0;\n"
    "    wincl.cbWndExtra = 0;\n");
    sprintf(linea, "    wincl.hbrBackground = CreateSolidBrush(RGB(%i,%i,%i));\n\n", initwindow.r, initwindow.g, initwindow.b);
    strcat(buffer, linea);
    strcat(buffer, "    if (!RegisterClassEx (&wincl))return 0;\n\n"
    "    hwnd = CreateWindowEx (\n");
    if(initwindow.exstyle & WS_EX_CLIENTEDGE) strcat(buffer, "        WS_EX_CLIENTEDGE\n");
    else strcat(buffer, "        0,\n");
    strcat(buffer, "        szClassName,\n");
    sprintf(linea, "        \"%s\",\n", initwindow.title);
    strcat(buffer, linea);
    strcat(buffer, "        WS_OVERLAPPEDWINDOW,\n");
    if(initwindow.x==(signed long)CW_USEDEFAULT)strcat(buffer, "        CW_USEDEFAULT,\n");
    else
    {
        sprintf(linea, "        %i,\n", initwindow.x);
        strcat(buffer, linea);
    }
    if(initwindow.y==(signed long)CW_USEDEFAULT)strcat(buffer, "        CW_USEDEFAULT,\n");
    else
    {
        sprintf(linea, "        %i,\n", initwindow.y);
        strcat(buffer, linea);
    }
    sprintf(linea, "        %i,\n        %i,\n", initwindow.w, initwindow.h);
    strcat(buffer, linea);
    strcat(buffer,
    "        HWND_DESKTOP,\n"
    "        NULL,\n"
    "        hThisInstance,\n"
    "        NULL);\n\n");
    strcat(buffer,
    "    ShowWindow (hwnd, nCmdShow);\n\n"
    "    while (GetMessage (&messages, NULL, 0, 0))\n"
    "    {\n"
    "        TranslateMessage(&messages);\n"
    "        DispatchMessage(&messages);\n"
    "    }\n"
    "    return messages.wParam;\n"
    "}\n\n\n"

    "LRESULT CALLBACK WindowProcedure (HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)\n"
    "{\n"
    "    switch (message)\n"
    "    {\n"
    "        case WM_CREATE:\n");
    for(j=f_ini;j->sig!=0;j=j->sig)
    {
        if(j->used)
        {
            //static HFONT hFont = CreateFont(8, 0, 0, 0, 100, 0, 0, 0,0, 0, 0, 0, VARIABLE_PITCH | FF_SWISS, "Helv");
            sprintf(linea, "            static HFONT hFont%i = CreateFont(%i, 0, 0, 0, ", fcount++, j->tam);
            strcat(buffer, linea);
            if(j->gros==FW_BOLD) strcat(buffer, "FW_BOLD, ");
            else strcat(buffer, "FW_THIN, ");
            if(j->italic) strcat(buffer, "(DWORD)true, ");
            else strcat(buffer, "(DWORD)false, ");
            if(j->underline) strcat(buffer, "(DWORD)true, ");
            else strcat(buffer, "(DWORD)false, ");
            if(j->strikeout) strcat(buffer, "(DWORD)true, ");
            else strcat(buffer, "(DWORD)false, ");
            sprintf(linea, "0, 0, 0, 0, VARIABLE_PITCH | FF_SWISS, \"%s\");\n", j->fnombre);
            strcat(buffer, linea);
        }
    }
    for(i=c_ini;i->sig!=0;i=i->sig)
    {
        if(i->type==BUTTON)
        {
            strcpy(aux[0], "0");
            strcpy(aux[1], "WS_CHILD");

            if(i->exstyle & WS_EX_CLIENTEDGE) strcat(aux[0], "|WS_ EX_CLIENTEDGE");
            if(i->style & WS_VISIBLE) strcat(aux[1], "|WS_VISIBLE");
            if(i->style & WS_TABSTOP) strcat(aux[1], "|WS_TABSTOP");
            if(i->style & WS_BORDER) strcat(aux[1], "|WS_BORDER");
            sprintf(linea, "            static HWND hwndButton%i = CreateWindowEx(%s, \"%s\", \"%s\", %s, %i, %i, %i, %i, hwnd, 0, miinstance, NULL);\n",
            bcount++, aux[0], BUTTON, i->title, aux[1], i->x, i->y, i->w, i->h);
        }
        else if(i->type==EDIT)
        {
            strcpy(aux[0], "0");
            strcpy(aux[1], "WS_CHILD");

            if(i->exstyle & WS_EX_CLIENTEDGE) strcat(aux[0], "|WS_ EX_CLIENTEDGE");
            if(i->style & WS_VISIBLE) strcat(aux[1], "|WS_VISIBLE");
            if(i->style & WS_TABSTOP) strcat(aux[1], "|WS_TABSTOP");
            if(i->style & WS_BORDER) strcat(aux[1], "|WS_BORDER");
            sprintf(linea, "            static HWND hwndEdit%i = CreateWindowEx(%s, \"%s\", \"%s\", %s, %i, %i, %i, %i, hwnd, 0, miinstance, NULL);\n",
            ecount++, aux[0], EDIT, i->title, aux[1], i->x, i->y, i->w, i->h);
        }
        else if(i->type==STATIC)
        {
            strcpy(aux[0], "0");
            strcpy(aux[1], "WS_CHILD");

            if(i->exstyle & WS_EX_CLIENTEDGE) strcat(aux[0], "|WS_ EX_CLIENTEDGE");
            if(i->style & WS_VISIBLE) strcat(aux[1], "|WS_VISIBLE");
            if(i->style & WS_TABSTOP) strcat(aux[1], "|WS_TABSTOP");
            if(i->style & WS_BORDER) strcat(aux[1], "|WS_BORDER");
            sprintf(linea, "            static HWND hwndStatic%i = CreateWindowEx(%s, \"%s\", \"%s\", %s, %i, %i, %i, %i, hwnd, 0, miinstance, NULL);\n",
            scount++, aux[0], STATIC, i->title, aux[1], i->x, i->y, i->w, i->h);
        }
        strcat(buffer, linea);
    }
    fcount=1;
    int ab=1, ae=1, as=1;
    for(j=f_ini;j->sig!=0;j=j->sig)
    {
        if(j->used)
        {
            ab=ae=as=1;
            for(i=c_ini;i->sig!=0;i=i->sig)
            {
                if(i->fuente==j)
                {
                    if(i->type==BUTTON) sprintf(linea, "            SendMessage(hwndButton%i, WM_SETFONT, (WPARAM) hFont%i, true);\n", ab, fcount);
                    else if(i->type==EDIT) sprintf(linea, "            SendMessage(hwndEdit%i, WM_SETFONT, (WPARAM) hFont%i, true);\n", ae, fcount);
                    else if(i->type==STATIC) sprintf(linea, "            SendMessage(hwndStatic%i, WM_SETFONT, (WPARAM) hFont%i, true);\n", as, fcount);
                    strcat(buffer, linea);
                }
                if(i->type==BUTTON) ab++;
                else if(i->type==EDIT) ae++;
                else if(i->type==STATIC) as++;
            }
            fcount++;
        }
    }
    /*for(i=c_ini;i->sig!=0;i=i->sig)
    {
        if(i->fuente)
        {
            fcount=0;
            for(j=f_ini;j->sig!=0;j=j->sig)
        }
    }*/
    for(i=c_ini;i->sig!=0;i=i->sig)
    {
        if(i->type==EDIT && i->color_f==true)
        {
            sprintf(linea, "            static HBRUSH pincel%i=CreateSolidBrush(RGB(%i,%i,%i));\n", pcount++, i->rf, i->gf, i->bf);
            strcat(buffer, linea);
        }
    }
    strcat(buffer, "            break;\n");
    strcat(buffer, "        case WM_CTLCOLOREDIT:\n");
    pcount=1;
    for(i=c_ini;i->sig!=0;i=i->sig)
    {
        if(i->type==EDIT)
        {
            acount++;
            if(i->color_l)
            {
                if(primero)
                {
                    strcat(buffer, "            ");
                    primero=false;
                }
                else strcat(buffer, "            else ");

                sprintf(linea, "if(lParam==(LPARAM)hwndEdit%i)\n"
                               "            {\n"
                               "                SetTextColor((HDC)wParam, RGB(%i,%i,%i));\n", acount, i->rl, i->gl, i->bl);
                               strcat(buffer, linea);
                               if(i->color_f)
                               {
                                   sprintf(linea, "                SetBkColor((HDC)wParam, RGB(%i,%i,%i));\n"
                                                  "                return (LRESULT)pincel%i;\n"
                                                  "            }\n", i->rf, i->gf, i->bf, pcount++);
                                   strcat(buffer, linea);
                                }
                                else
                                {
                                    strcat(buffer,
                                    "                return 0;\n"
                                    "            }\n");
                                }
            }
            else if(i->color_f)
            {
                if(primero)
                {
                    strcat(buffer, "            ");
                    primero=false;
                }
                else strcat(buffer, "            else ");
                sprintf(linea, "if(lParam==(LPARAM)hwndEdit%i)\n"
                               "            {\n"
                               "                SetBkColor((HDC)wParam, RGB(%i,%i,%i));\n"
                               "                return (LRESULT)pincel%i;\n"
                               "            }\n", acount, i->rf, i->gf, i->bf, pcount++);
                strcat(buffer, linea);
            }
        }
    }

    strcat(buffer, "            break;\n");
    strcat(buffer,
    "        case WM_DESTROY:\n");
    strcat(buffer,
    "            PostQuitMessage (0);\n"
    "            break;\n"
    "        default:\n"
    "            return DefWindowProc (hwnd, message, wParam, lParam);\n"
    "    }\n"
    "    return 0;\n"
    "}\n");

    GlobalUnlock(hgbuffer);
    if(OpenClipboard(hwnd))
    {
        EmptyClipboard();
        SetClipboardData(CF_TEXT, hgbuffer);
        CloseClipboard();
    }
    //printf(buffer);
    //auxstrpt=buffer;
    //DialogBox(miinstance, "VerCodigo", NULL, vc_proc);
    GlobalFree(hgbuffer);
}

