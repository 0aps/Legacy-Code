/* Identificadores */ 

/* Identificadores de comandos */
#define CM_DIALOGO 101

/* Identificadores de di�logo */
#define ID_SCROLLH 100
#define ID_EDITH   101
#define ID_SCROLLV 102
#define ID_EDITV   103

