/* Identificadores */ 

/* Identificadores de comandos */
#define CM_DIALOGO  101
#define CM_DIALOGO2 102
#define TEXTO       100

