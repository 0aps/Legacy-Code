/* Identificadores */

/* Identificadores de comandos */
#define CM_DIALOGO 101

#define ID_NORMAL	    101
#define ID_AUTO	        102
#define ID_TRISTATE     103
#define ID_AUTOTRISTATE 104
#define ID_AUTOPUSH     105
#define ID_AUTOTRIPUSH  106
#define ID_DERECHA      107
#define ID_PLANO        108

