#include <windows.h>

#include "IDS.h"
#define DESHABILITADO -1

/*  Declaraci�n del procedimiento de ventana  */
LRESULT CALLBACK WindowProcedure (HWND, UINT, WPARAM, LPARAM);
BOOL CALLBACK DlgProc(HWND, UINT, WPARAM, LPARAM);

// Datos de la aplicaci�n
typedef struct stDatos {
   BOOL Normal;
   BOOL Auto;
   int TriState;
   int AutoTriState;
   BOOL AutoPush;
   int AutoTriPush;
   BOOL Derecha;
   BOOL Plano;
} DATOS;

int WINAPI WinMain (HINSTANCE hThisInstance,
                    HINSTANCE hPrevInstance,
                    LPSTR lpszArgument,
                    int nFunsterStil)
{
    HWND hwnd;               /* Manipulador de ventana */
    MSG mensaje;             /* Mensajes recibidos por la aplicaci�n */
    WNDCLASSEX wincl;        /* Estructura de datos para la clase de ventana */

    /* Estructura de la ventana */
    wincl.hInstance = hThisInstance;
    wincl.lpszClassName = "NUESTRA_CLASE";
    wincl.lpfnWndProc = WindowProcedure;      /* Esta funci�n es invocada por Windows */
    wincl.style = CS_DBLCLKS;                 /* Captura los doble-clicks */
    wincl.cbSize = sizeof (WNDCLASSEX);

    /* Usar icono y puntero por defector */
    wincl.hIcon = LoadIcon (NULL, IDI_APPLICATION);
    wincl.hIconSm = LoadIcon (NULL, IDI_APPLICATION);
    wincl.hCursor = LoadCursor (NULL, IDC_ARROW);
    wincl.lpszMenuName = "Menu";
    wincl.cbClsExtra = 0;                      /* Sin informaci�n adicional para la */
    wincl.cbWndExtra = 0;                      /* clase o la ventana */
    /* Usar el color de fondo por defecto para la ventana */
    wincl.hbrBackground = GetSysColorBrush(COLOR_BACKGROUND);

    /* Registrar la clase de ventana, si falla, salir del programa */
    if(!RegisterClassEx(&wincl)) return 0;
    
    /* La clase est� registrada, crear la ventana */
    hwnd = CreateWindowEx(
           0,                   /* Posibilidades de variaci�n */
           "NUESTRA_CLASE",     /* Nombre de la clase */
           "Ejemplo 014",       /* Texto del t�tulo */
           WS_OVERLAPPEDWINDOW, /* Tipo por defecto */
           CW_USEDEFAULT,       /* Windows decide la posici�n */
           CW_USEDEFAULT,       /* donde se coloca la ventana */
           544,                 /* Ancho */
           375,                 /* Alto en pixels */
           HWND_DESKTOP,        /* La ventana es hija del escritorio */
           NULL,                /* Sin men� */
           hThisInstance,       /* Manipulador de instancia */
           NULL                 /* No hay datos de creaci�n de ventana */
    );

    /* Mostrar la ventana */
    ShowWindow(hwnd, SW_SHOWDEFAULT);

    /* Bucle de mensajes, se ejecuta hasta que haya error o GetMessage devuelva FALSE */
    while(TRUE == GetMessage(&mensaje, NULL, 0, 0))
    {
        /* Traducir mensajes de teclas virtuales a mensajes de caracteres */
        TranslateMessage(&mensaje);
        /* Enviar mensaje al procedimiento de ventana */
        DispatchMessage(&mensaje);
    }

    /* Salir con valor de retorno */
    return mensaje.wParam;
}

/*  Esta funci�n es invocada por la funci�n DispatchMessage()  */
LRESULT CALLBACK WindowProcedure(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
    static DATOS Datos;
    static HINSTANCE hInstance;
    
    switch (msg)                  /* manipulador del mensaje */
    {
        case WM_CREATE:
           hInstance = ((LPCREATESTRUCT)lParam)->hInstance;
           /* Inicializaci�n */
           Datos.Normal = TRUE;
           Datos.Auto = TRUE;
           Datos.TriState = (int)FALSE;
           Datos.AutoTriState = (int)FALSE;
           Datos.AutoPush = FALSE;
           Datos.AutoTriPush = (int)TRUE;
           Datos.Derecha = TRUE;
           Datos.Plano = FALSE;
           return 0;
           break;
        case WM_COMMAND:
           if(LOWORD(wParam) == CM_DIALOGO)
              DialogBoxParam(hInstance, "DialogoPrueba", hwnd, DlgProc, (LPARAM)&Datos); 
           break;
        case WM_DESTROY:
           PostQuitMessage(0);    /* env�a un mensaje WM_QUIT a la cola de mensajes */
           break;
        default:                  /* para los mensajes de los que no nos ocupamos */
           return DefWindowProc(hwnd, msg, wParam, lParam);
    }
    return 0;
}

BOOL CALLBACK DlgProc(HWND hDlg, UINT msg, WPARAM wParam, LPARAM lParam)
{
    WORD status;
    UINT indice;
    int i;
    char resultado[240];
    static DATOS *Datos;

    switch (msg)                  /* manipulador del mensaje */
    {
        case WM_INITDIALOG:
           Datos = (DATOS*)lParam; 
           // Estado inicial de los checkbox
           CheckDlgButton(hDlg, ID_NORMAL, 
              Datos->Normal ? BST_CHECKED : BST_UNCHECKED);
           CheckDlgButton(hDlg, ID_AUTO, 
              Datos->Auto ? BST_CHECKED : BST_UNCHECKED);
           if(Datos->TriState != DESHABILITADO)
              CheckDlgButton(hDlg, ID_TRISTATE, 
                 Datos->TriState ? BST_CHECKED : BST_UNCHECKED);
           else
              CheckDlgButton(hDlg, ID_TRISTATE, BST_INDETERMINATE);
           if(Datos->AutoTriState != DESHABILITADO)
              CheckDlgButton(hDlg, ID_AUTOTRISTATE, 
                 Datos->AutoTriState ? BST_CHECKED : BST_UNCHECKED);
           else
              CheckDlgButton(hDlg, ID_AUTOTRISTATE, BST_INDETERMINATE);
           CheckDlgButton(hDlg, ID_AUTOPUSH, 
              Datos->AutoPush ? BST_CHECKED : BST_UNCHECKED);
           // Usando mensajes:
           if(Datos->AutoTriPush != DESHABILITADO)
              SendDlgItemMessage(hDlg, ID_AUTOTRIPUSH, BM_SETCHECK, 
                 Datos->AutoTriPush ? (WPARAM)BST_CHECKED : (WPARAM)BST_UNCHECKED, 0);
           else
              SendDlgItemMessage(hDlg, ID_AUTOTRIPUSH, BM_SETCHECK, 
                 (WPARAM)BST_INDETERMINATE, 0);
           SendDlgItemMessage(hDlg, ID_DERECHA, BM_SETCHECK, 
              Datos->Derecha ? (WPARAM)BST_CHECKED : (WPARAM)BST_UNCHECKED, 0);
           SendDlgItemMessage(hDlg, ID_PLANO, BM_SETCHECK, 
              Datos->Plano ? (WPARAM)BST_CHECKED : (WPARAM)BST_UNCHECKED, 0);
           SetFocus(GetDlgItem(hDlg, ID_NORMAL));
           return FALSE;
           break;
        case WM_COMMAND:
           switch(LOWORD(wParam)) {
              case ID_NORMAL:
                 if(SendDlgItemMessage(hDlg, ID_NORMAL, BM_GETCHECK, 0, 0) == BST_CHECKED)
                    SendDlgItemMessage(hDlg, ID_NORMAL, BM_SETCHECK, 
                       (WPARAM)BST_UNCHECKED, 0);
                 else
                    SendDlgItemMessage(hDlg, ID_NORMAL, BM_SETCHECK, 
                       (WPARAM)BST_CHECKED, 0);
                 return TRUE;

              case ID_TRISTATE:
                 if(IsDlgButtonChecked(hDlg, ID_TRISTATE) == BST_INDETERMINATE)
                    CheckDlgButton(hDlg, ID_TRISTATE, BST_UNCHECKED);
                 else if(IsDlgButtonChecked(hDlg, ID_TRISTATE) == BST_CHECKED) 
                    CheckDlgButton(hDlg, ID_TRISTATE, BST_INDETERMINATE);
                 else
                    CheckDlgButton(hDlg, ID_TRISTATE, BST_CHECKED);
                 return TRUE;
              case IDOK:
                 Datos->Normal = (IsDlgButtonChecked(hDlg, ID_NORMAL) == BST_CHECKED);
                 Datos->Auto = (IsDlgButtonChecked(hDlg, ID_AUTO) == BST_CHECKED);
                 if(IsDlgButtonChecked(hDlg, ID_TRISTATE) == BST_INDETERMINATE)
                    Datos->TriState = DESHABILITADO;
                 else
                    Datos->TriState = (IsDlgButtonChecked(hDlg, ID_TRISTATE) == BST_CHECKED);
                 if(IsDlgButtonChecked(hDlg, ID_AUTOTRISTATE) == BST_INDETERMINATE)
                    Datos->AutoTriState = DESHABILITADO;
                 else
                    Datos->AutoTriState = (IsDlgButtonChecked(hDlg, ID_AUTOTRISTATE) == BST_CHECKED);
                 Datos->AutoPush = (IsDlgButtonChecked(hDlg, ID_AUTOPUSH) == BST_CHECKED);
                 if(IsDlgButtonChecked(hDlg, ID_AUTOTRIPUSH) == BST_INDETERMINATE)
                    Datos->AutoTriPush = DESHABILITADO;
                 else
                    Datos->AutoTriPush = (IsDlgButtonChecked(hDlg, ID_AUTOTRIPUSH) == BST_CHECKED);
                 Datos->Derecha = (IsDlgButtonChecked(hDlg, ID_DERECHA) == BST_CHECKED);
                 Datos->Plano = (IsDlgButtonChecked(hDlg, ID_PLANO) == BST_CHECKED);
                 EndDialog(hDlg, FALSE);
                 return TRUE;
              case IDCANCEL:
                 EndDialog(hDlg, FALSE);
                 return FALSE;
            }
    }
    return FALSE;
}

