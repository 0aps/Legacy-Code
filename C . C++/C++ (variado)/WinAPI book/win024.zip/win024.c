#include <windows.h>
#include "ids.h"

/* Declaraci�n del procedimiento de ventana */
LRESULT CALLBACK WindowProcedure(HWND, UINT, WPARAM, LPARAM);
BOOL CALLBACK DlgProcRect(HWND, UINT, WPARAM, LPARAM);
BOOL CALLBACK DlgProcModif(HWND, UINT, WPARAM, LPARAM);

int WINAPI WinMain (HINSTANCE hThisInstance,
                    HINSTANCE hPrevInstance,
                    LPSTR lpszArgument,
                    int nFunsterStil)
{
    HWND hwnd;               /* Manipulador de ventana */
    MSG mensaje;             /* Mensajes recibidos por la aplicaci�n */
    WNDCLASSEX wincl;        /* Estructura de datos para la clase de ventana */

    /* Estructura de la ventana */
    wincl.hInstance = hThisInstance;
    wincl.lpszClassName = "NUESTRA_CLASE";
    wincl.lpfnWndProc = WindowProcedure;      /* Esta funci�n es invocada por Windows */
    wincl.style = CS_DBLCLKS;                 /* Captura los doble-clicks */
    wincl.cbSize = sizeof (WNDCLASSEX);

    /* Usar icono y puntero por defector */
    wincl.hIcon = LoadIcon (hThisInstance, "Icono");
    wincl.hIconSm = LoadIcon (hThisInstance, "Icono");
    wincl.hCursor = LoadCursor (NULL, IDC_ARROW);
    wincl.lpszMenuName = "Menu";
    wincl.cbClsExtra = 0;                      /* Sin informaci�n adicional para la */
    wincl.cbWndExtra = 0;                      /* clase o la ventana */
    /* Usar el color de fondo por defecto para es escritorio */
    wincl.hbrBackground = GetSysColorBrush(COLOR_BACKGROUND);

    /* Registrar la clase de ventana, si falla, salir del programa */
    if(!RegisterClassEx(&wincl)) return 0;
      
    /* La clase est� registrada, crear la ventana */
    hwnd = CreateWindowEx(
           0,                   /* Posibilidades de variaci�n */
           "NUESTRA_CLASE",     /* Nombre de la clase */
           "Ejemplo 024",       /* Texto del t�tulo */
           WS_OVERLAPPEDWINDOW, /* Tipo por defecto */
           CW_USEDEFAULT,       /* Windows decide la posici�n */
           CW_USEDEFAULT,       /* donde se coloca la ventana */
           450,
           450,
           HWND_DESKTOP,        /* La ventana es hija del escritorio */
           NULL,                /* Sin men� */
           hThisInstance,       /* Manipulador de instancia */
           NULL                 /* No hay datos de creaci�n de ventana */
    );

    /* Mostrar la ventana */
    ShowWindow(hwnd, SW_SHOWDEFAULT);

    /* Bucle de mensajes, se ejecuta hasta que haya error o GetMessage devuelva FALSE */
    while(TRUE == GetMessage(&mensaje, NULL, 0, 0))
    {
        /* Traducir mensajes de teclas virtuales a mensajes de caracteres */
        TranslateMessage(&mensaje);
        /* Enviar mensaje al procedimiento de ventana */
        DispatchMessage(&mensaje);
    }

    /* Salir con valor de retorno */
    return mensaje.wParam;
}

/* Esta funci�n es llamada por la funci�n del API DispatchMessage() */
LRESULT CALLBACK WindowProcedure(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
    HDC hdc;
    PAINTSTRUCT ps;
    int i;
    static RECT re[5];
    static POINT punto;
    static HINSTANCE hInstance;
    static HBRUSH pincel[5];
    static BOOL verUnion;
    static BOOL verInterseccion;
    static BOOL verDiferencia;

    switch (msg)                  /* manipulador del mensaje */
    {
        case WM_CREATE:
           hInstance = ((LPCREATESTRUCT)lParam)->hInstance;
           verUnion = verInterseccion = verDiferencia = FALSE;
           SetRect(&re[0], 10,10,200,200);
           SetRect(&re[1], 50,50,250,250);
           IntersectRect(&re[2], &re[0], &re[1]);
           UnionRect(&re[3], &re[0], &re[1]);
           SubtractRect(&re[4], &re[0], &re[1]);
           pincel[0] = CreateSolidBrush(RGB(255,0,0));
           pincel[1] = CreateSolidBrush(RGB(0,255,0));
           pincel[2] = CreateHatchBrush(HS_FDIAGONAL, RGB(0,0,255));
           pincel[3] = CreateHatchBrush(HS_DIAGCROSS, RGB(255,255,0));
           pincel[4] = CreateHatchBrush(HS_CROSS, RGB(255,0,255));
           punto.x=0;
           punto.y=0;
           break;
        case WM_PAINT:
           hdc = BeginPaint(hwnd, &ps);
           if(verUnion) {
              SelectObject(hdc, pincel[3]);
              Rectangle(hdc, re[3].left, re[3].top, re[3].right, re[3].bottom);
           }
           SelectObject(hdc, pincel[0]);
           Rectangle(hdc, re[0].left, re[0].top, re[0].right, re[0].bottom);
           SelectObject(hdc, pincel[1]);
           Rectangle(hdc, re[1].left, re[1].top, re[1].right, re[1].bottom);
           if(verInterseccion) {
              SelectObject(hdc, pincel[2]);
              Rectangle(hdc, re[2].left, re[2].top, re[2].right, re[2].bottom);
           }
           if(verDiferencia) {
              SelectObject(hdc, pincel[4]);
              Rectangle(hdc, re[4].left, re[4].top, re[4].right, re[4].bottom);
           }
           EndPaint(hwnd, &ps);
           break;
        case WM_COMMAND:
           switch(LOWORD(wParam)) {
              case CM_RECT1:
                 DialogBoxParam(hInstance, "DialogoRect", hwnd,
                    DlgProcRect, (LPARAM)&re[0]);
                 break;
              case CM_RECT2:
                 DialogBoxParam(hInstance, "DialogoRect", hwnd,
                    DlgProcRect, (LPARAM)&re[1]);
                 break;
              case CM_INTERSECCION:
                 verUnion = verDiferencia = FALSE;
                 verInterseccion = TRUE;
                 break;
              case CM_UNION:
                 verInterseccion = verDiferencia = FALSE;
                 verUnion = TRUE;
                 break;
              case CM_DIFERENCIA:
                 verUnion = verInterseccion = FALSE;
                 verDiferencia = TRUE;
                 break;
              case CM_INFLAR1:
              case CM_INFLAR2:
                 DialogBoxParam(hInstance, "DialogoInflarMover", hwnd,
                    DlgProcModif, (LPARAM)&punto);
                 if(LOWORD(wParam) == CM_INFLAR1)
                    InflateRect(&re[0], punto.x, punto.y);
                 else
                    InflateRect(&re[1], punto.x, punto.y);
                 break;
              case CM_MOVER1:
              case CM_MOVER2:
                 DialogBoxParam(hInstance, "DialogoInflarMover", hwnd,
                    DlgProcModif, (LPARAM)&punto);
                 if(LOWORD(wParam) == CM_MOVER1)
                    OffsetRect(&re[0], punto.x, punto.y);
                 else
                    OffsetRect(&re[1], punto.x, punto.y);
                 break;
           }
           IntersectRect(&re[2], &re[0], &re[1]);
           UnionRect(&re[3], &re[0], &re[1]);
           SubtractRect(&re[4], &re[0], &re[1]);
           InvalidateRect(hwnd, NULL, TRUE);
           break;
        case WM_DESTROY:
           for(i = 0; i < 4; i++) DeleteObject(pincel[i]);
           PostQuitMessage(0);    /* env�a un mensaje WM_QUIT a la cola de mensajes */
           break;
        default:                  /* para los mensajes de los que no nos ocupamos */
           return DefWindowProc(hwnd, msg, wParam, lParam);
    }
    return 0;
}

BOOL CALLBACK DlgProcRect(HWND hDlg, UINT msg, WPARAM wParam, LPARAM lParam)
{
    BOOL arribaOk, abajoOk, derechaOk, izquierdaOk;
    static RECT *re;
    RECT verificar;

    switch (msg)                  /* manipulador del mensaje */
    {
        case WM_DESTROY:
           break;
        case WM_INITDIALOG:
           re = (RECT *)lParam;
           SetDlgItemInt(hDlg, ID_ARRIBA, (UINT)re->top, FALSE);
           SetDlgItemInt(hDlg, ID_ABAJO, (UINT)re->bottom, FALSE);
           SetDlgItemInt(hDlg, ID_IZQUIERDA, (UINT)re->left, FALSE);
           SetDlgItemInt(hDlg, ID_DERECHA, (UINT)re->right, FALSE);
           SetFocus(GetDlgItem(hDlg, ID_ARRIBA));
           return FALSE;
        case WM_COMMAND:
           switch(LOWORD(wParam)) {
              case IDOK:
                 verificar.top = GetDlgItemInt(hDlg, ID_ARRIBA, &arribaOk, FALSE);
                 verificar.bottom = GetDlgItemInt(hDlg, ID_ABAJO, &abajoOk, FALSE);
                 verificar.left = GetDlgItemInt(hDlg, ID_IZQUIERDA, &izquierdaOk, FALSE);
                 verificar.right = GetDlgItemInt(hDlg, ID_DERECHA, &derechaOk, FALSE);
                 if(arribaOk && abajoOk && derechaOk && izquierdaOk) {
                    if(!IsRectEmpty(&verificar)) {
                       CopyRect(re, &verificar);
                       EndDialog(hDlg, FALSE);
                    }
                    else
                       MessageBox(hDlg, "Rect�ngulo no v�lido", "Error",
                          MB_ICONEXCLAMATION | MB_OK);
                 }
                 else
                    MessageBox(hDlg, "Valores no num�ricos", "Error",
                       MB_ICONEXCLAMATION | MB_OK);
                 break;
              case IDCANCEL:
                 EndDialog(hDlg, FALSE);
                 break;
           }
           return TRUE;
    }
    return FALSE;
}

BOOL CALLBACK DlgProcModif(HWND hDlg, UINT msg, WPARAM wParam, LPARAM lParam)
{
    BOOL hOk, vOk;
    static POINT *punto;
    POINT verificar;

    switch (msg)                  /* manipulador del mensaje */
    {
        case WM_INITDIALOG:
           punto = (POINT *)lParam;
           SetDlgItemInt(hDlg, ID_HORIZONTAL, (UINT)punto->x, TRUE);
           SetDlgItemInt(hDlg, ID_VERTICAL, (UINT)punto->y, TRUE);
           SetFocus(GetDlgItem(hDlg, ID_HORIZONTAL));
           return FALSE;
        case WM_COMMAND:
           switch(LOWORD(wParam)) {
              case IDOK:
                 verificar.x = GetDlgItemInt(hDlg, ID_HORIZONTAL, &hOk, TRUE);
                 verificar.y = GetDlgItemInt(hDlg, ID_VERTICAL, &vOk, TRUE);
                 if(hOk && vOk) {
                    *punto = verificar;
                    EndDialog(hDlg, FALSE);
                 }
                 else
                    MessageBox(hDlg, "Valores no num�ricos", "Error",
                       MB_ICONEXCLAMATION | MB_OK);
                 break;
              case IDCANCEL:
                 EndDialog(hDlg, FALSE);
                 break;
           }
           return TRUE;
    }
    return FALSE;
}

