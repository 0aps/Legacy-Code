// Identificadores de men�
#define CM_RECT1      100
#define CM_RECT2      101
#define CM_INTERSECCION 102
#define CM_UNION       103
#define CM_DIFERENCIA  104

#define CM_INFLAR1    200
#define CM_INFLAR2    201
#define CM_MOVER1     202
#define CM_MOVER2     203

#define ID_IZQUIERDA  100
#define ID_DERECHA    101
#define ID_ARRIBA     102
#define ID_ABAJO      103

#define ID_VERTICAL   100
#define ID_HORIZONTAL 101

