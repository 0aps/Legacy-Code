#include <windows.h>
#include <string.h>
#include <stdio.h>
#include "ids.h"

#define NUMCOLORES 18

/* Declaraci�n del procedimiento de ventana */
LRESULT CALLBACK WindowProcedure(HWND, UINT, WPARAM, LPARAM);
BOOL CALLBACK DlgProcInfo(HWND, UINT, WPARAM, LPARAM);

int NumeroColores(HWND, HPALETTE);
HPALETTE ObtenerPaleta(HWND hwnd);

int WINAPI WinMain (HINSTANCE hThisInstance,
                    HINSTANCE hPrevInstance,
                    LPSTR lpszArgument,
                    int nFunsterStil)
{
    HWND hwnd;               /* Manipulador de ventana */
    MSG mensaje;             /* Mensajes recibidos por la aplicaci�n */
    WNDCLASSEX wincl;        /* Estructura de datos para la clase de ventana */

    /* Estructura de la ventana */
    wincl.hInstance = hThisInstance;
    wincl.lpszClassName = "NUESTRA_CLASE";
    wincl.lpfnWndProc = WindowProcedure;      /* Esta funci�n es invocada por Windows */
    wincl.style = CS_DBLCLKS;                 /* Captura los doble-clicks */
    wincl.cbSize = sizeof (WNDCLASSEX);

    /* Usar icono y puntero por defector */
    wincl.hIcon = LoadIcon (hThisInstance, "Icono");
    wincl.hIconSm = LoadIcon (hThisInstance, "Icono");
    wincl.hCursor = LoadCursor (NULL, IDC_ARROW);
    wincl.lpszMenuName = "Menu";
    wincl.cbClsExtra = 0;                      /* Sin informaci�n adicional para la */
    wincl.cbWndExtra = 0;                      /* clase o la ventana */
    /* Usar el color de fondo por defecto para la ventana */
    wincl.hbrBackground = GetSysColorBrush(COLOR_BACKGROUND);

    /* Registrar la clase de ventana, si falla, salir del programa */
    if(!RegisterClassEx(&wincl)) return 0;
      
    /* La clase est� registrada, crear la ventana */
    hwnd = CreateWindowEx(
           0,                   /* Posibilidades de variaci�n */
           "NUESTRA_CLASE",     /* Nombre de la clase */
           "Ejemplo 020",       /* Texto del t�tulo */
           WS_OVERLAPPEDWINDOW, /* Tipo por defecto */
           CW_USEDEFAULT,       /* Windows decide la posici�n */
           CW_USEDEFAULT,       /* donde se coloca la ventana */
           450,
           150,
           HWND_DESKTOP,        /* La ventana es hija del escritorio */
           NULL,                /* Sin men� */
           hThisInstance,       /* Manipulador de instancia */
           NULL                 /* No hay datos de creaci�n de ventana */
    );

    /* Mostrar la ventana */
    ShowWindow(hwnd, SW_SHOWDEFAULT);

    /* Bucle de mensajes, se ejecuta hasta que haya error o GetMessage devuelva FALSE */
    while(TRUE == GetMessage(&mensaje, NULL, 0, 0))
    {
        /* Traducir mensajes de teclas virtuales a mensajes de caracteres */
        TranslateMessage(&mensaje);
        /* Enviar mensaje al procedimiento de ventana */
        DispatchMessage(&mensaje);
    }

    /* Salir con valor de retorno */
    return mensaje.wParam;
}

/* Esta funci�n es llamada por la funci�n del API DispatchMessage() */
LRESULT CALLBACK WindowProcedure(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
    HDC hDC;
    PAINTSTRUCT ps;
    HBRUSH hBrush, hOldBrush;
    static HINSTANCE hInstance;
    UINT i, n;
    char cad[120];
    static HPALETTE hPaleta, hPaletaOld;
    static int Activo;
    HANDLE hLogPaleta;
    /* Paleta de gamas de verde */
    PALETTEENTRY Color[20] = {
       //peRed, peGreen, peBlue, peFlags
       {0,0,0,PC_NOCOLLAPSE},
       {0,20,0,PC_NOCOLLAPSE},
       {0,40,0,PC_NOCOLLAPSE},
       {0,60,0,PC_NOCOLLAPSE},
       {0,80,0,PC_NOCOLLAPSE},
       {0,90,0,PC_NOCOLLAPSE},
       {0,100,0,PC_NOCOLLAPSE},
       {0,110,0,PC_NOCOLLAPSE},
       {0,120,0,PC_NOCOLLAPSE},
       {0,130,0,PC_NOCOLLAPSE},
       {0,140,0,PC_NOCOLLAPSE},
       {0,150,0,PC_NOCOLLAPSE},
       {0,160,0,PC_NOCOLLAPSE},
       {0,170,0,PC_NOCOLLAPSE},
       {0,180,0,PC_NOCOLLAPSE},
       {0,190,0,PC_NOCOLLAPSE},
       {0,200,0,PC_NOCOLLAPSE},
       {0,210,0,PC_NOCOLLAPSE},
       {0,220,0,PC_NOCOLLAPSE},
       {0,230,0,PC_NOCOLLAPSE}
    };
    LOGPALETTE *logPaleta;
    
    switch (msg)                  /* manipulador del mensaje */
    {
        case WM_CREATE:
           // Leer paleta por defecto:
           // Obtener un manipulador a la paleta l�gica:
           hPaleta = ObtenerPaleta(hwnd);
                                 
           // Crear una paleta nueva:
           logPaleta = (LOGPALETTE*)malloc(sizeof(LOGPALETTE) + 
              sizeof(PALETTEENTRY) * NUMCOLORES);
           if(!logPaleta)
              MessageBox(hwnd, "No pude bloquear la memoria de la paleta", "Error", MB_OK);
		  
		   logPaleta->palVersion = 0x300;
           logPaleta->palNumEntries = NUMCOLORES;
           for(i = 0; i < NUMCOLORES; i++) {
              logPaleta->palPalEntry[i].peBlue  = Color[i].peBlue;
              logPaleta->palPalEntry[i].peGreen = Color[i].peGreen;
              logPaleta->palPalEntry[i].peRed   = Color[i].peRed;
              logPaleta->palPalEntry[i].peFlags = Color[i].peFlags;
           }

           hPaleta = CreatePalette(logPaleta);
           if(!hPaleta)
              MessageBox(hwnd, "No pude crear la paleta", "Error", MB_OK);
           free(logPaleta);
           Activo = FALSE;
           
           hInstance = ((LPCREATESTRUCT)lParam)->hInstance;
           break;
        case WM_PAINT:
           hDC = BeginPaint(hwnd, &ps);
           if(Activo) {
              hPaletaOld = SelectPalette(hDC, hPaleta, FALSE);
              n = NumeroColores(hwnd, hPaleta);
           }
           else n = NumeroColores(hwnd, NULL);
           for(i = 0; i < n; i++) {
              hBrush = CreateSolidBrush(PALETTEINDEX(i));
              hOldBrush = (HBRUSH)SelectObject(hDC, hBrush);
              Rectangle(hDC, 20+20*i, 20, 40+20*i, 40);
              SelectObject(hDC, hOldBrush);
              DeleteObject(hBrush);
           }
           if(Activo) SelectPalette(hDC, hPaletaOld, FALSE);
           EndPaint(hwnd, &ps);
           break;
        case WM_COMMAND:
           switch(LOWORD(wParam)) {
              case CM_INFO:
                 DialogBox(hInstance, "DlgInfo", hwnd, DlgProcInfo);
                 break;
              case CM_REDEFINIRPALETA:
                 Activo = TRUE;
                 InvalidateRect(hwnd, NULL, TRUE);
                 break;
              case CM_RESTAURARPALETA:
                 Activo = FALSE;
                 InvalidateRect(hwnd, NULL, TRUE);
                 break;
           }
           break;
        case WM_DESTROY:
           DeleteObject(hPaleta); 
           PostQuitMessage(0);    /* env�a un mensaje WM_QUIT a la cola de mensajes */
           break;
        default:                  /* para los mensajes de los que no nos ocupamos */
           return DefWindowProc(hwnd, msg, wParam, lParam);
    }
    return 0;
}

HPALETTE ObtenerPaleta(HWND hwnd)
{
   HDC hDC;
   HPALETTE hPaleta, hPaletaOld;
   LOGPALETTE *logPaleta;
   
   hDC = GetDC(hwnd);
   logPaleta = (LOGPALETTE*)malloc(sizeof(LOGPALETTE) + sizeof(PALETTEENTRY));
   if(!logPaleta)
      MessageBox(hwnd, "No pude bloquear la memoria de la paleta", "Error", MB_OK);
		  
   logPaleta->palVersion = 0x300;
   logPaleta->palNumEntries = 1;
   logPaleta->palPalEntry[0].peBlue  = 0;
   logPaleta->palPalEntry[0].peGreen = 0;
   logPaleta->palPalEntry[0].peRed   = 0;
   logPaleta->palPalEntry[0].peFlags = PC_NOCOLLAPSE;
     
   hPaleta = CreatePalette(logPaleta);
   if(!hPaleta) MessageBox(hwnd, "No pude crear la paleta", "Error", MB_OK);

   hPaletaOld = SelectPalette(hDC, hPaleta, FALSE);
   SelectPalette(hDC, hPaletaOld, FALSE);
   free(logPaleta);
   ReleaseDC(hwnd, hDC);
   return hPaletaOld;
}

int NumeroColores(HWND hwnd, HPALETTE hPaleta)
{
   if(!hPaleta) {
      if(hwnd) hPaleta = ObtenerPaleta(hwnd);
   }
   if(hPaleta)
      return GetPaletteEntries(hPaleta, 0, 0, NULL);
   return 0;
}

BOOL CALLBACK DlgProcInfo(HWND hDlg, UINT msg, WPARAM wParam, LPARAM lParam)
{
    HDC hDC;
    int i;
    char cad[120];
    
    switch (msg)                  /* manipulador del mensaje */
    {
        case WM_INITDIALOG:
           hDC = GetDC(NULL);
           // Soporte de paletas
           if(GetDeviceCaps(hDC, RASTERCAPS)) 
              SetDlgItemText(hDlg, ID_SOPORTAPALETA, "El dispositivo soporta paletas");
           else
              SetDlgItemText(hDlg, ID_SOPORTAPALETA, "El dispositivo no soporta paletas");
           // Colores reales
           i = GetDeviceCaps(hDC, NUMCOLORS);
           if(i == -1) 
              strcpy(cad, "El dispositivo actual tiene m�s de 8 bits por pixel");
           else 
              sprintf(cad, "NUMCOLORS: El tama�o de la tabla de colores es %d", i);
           SetDlgItemText(hDlg, ID_COLORESREALES, cad);
           // N�mero de colores en la paleta
           i = GetDeviceCaps(hDC, SIZEPALETTE);
           if(i == 0)
              strcpy(cad, "El contexto de dispositivo actual es true color");
           else
              sprintf(cad, "Colores en la paleta de sistema: %d", i);
           SetDlgItemText(hDlg, ID_COLORESPALETA, cad);
           // N�mero de colores sistema
           i = NumeroColores(hDlg, NULL);
           sprintf(cad, "N�mero de colores en paleta l�gica actual: %d", i);
           SetDlgItemText(hDlg, ID_COLORESSISTEMA, cad);
           ReleaseDC(NULL, hDC);
           return TRUE;
        case WM_COMMAND:
           EndDialog(hDlg, FALSE);
           return TRUE;
    }
    return FALSE;
}

