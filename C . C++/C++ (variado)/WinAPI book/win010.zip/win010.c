#include <windows.h>

#include "IDS.h"

/*  Declaraci�n del procedimiento de ventana  */
LRESULT CALLBACK WindowProcedure (HWND, UINT, WPARAM, LPARAM);
BOOL CALLBACK DlgProc(HWND, UINT, WPARAM, LPARAM);

/* Datos de la aplicaci�n */
typedef struct stDatos {
   int nCadenas;
   char Lista[MAX_CADENAS][80];
   char Item[3][80];
} DATOS;
 
int WINAPI WinMain (HINSTANCE hThisInstance,
                    HINSTANCE hPrevInstance,
                    LPSTR lpszArgument,
                    int nFunsterStil)
{
    HWND hwnd;               /* Manipulador de ventana */
    MSG mensaje;             /* Mensajes recibidos por la aplicaci�n */
    WNDCLASSEX wincl;        /* Estructura de datos para la clase de ventana */

    /* Estructura de la ventana */
    wincl.hInstance = hThisInstance;
    wincl.lpszClassName = "NUESTRA_CLASE";
    wincl.lpfnWndProc = WindowProcedure;      /* Esta funci�n es invocada por Windows */
    wincl.style = CS_DBLCLKS;                 /* Captura los doble-clicks */
    wincl.cbSize = sizeof (WNDCLASSEX);

    /* Usar icono y puntero por defector */
    wincl.hIcon = LoadIcon (NULL, IDI_APPLICATION);
    wincl.hIconSm = LoadIcon (NULL, IDI_APPLICATION);
    wincl.hCursor = LoadCursor (NULL, IDC_ARROW);
    wincl.lpszMenuName = "Menu";
    wincl.cbClsExtra = 0;                      /* Sin informaci�n adicional para la */
    wincl.cbWndExtra = 0;                      /* clase o la ventana */
    /* Usar el color de fondo por defecto para la ventana */
    wincl.hbrBackground = GetSysColorBrush(COLOR_BACKGROUND);

    /* Registrar la clase de ventana, si falla, salir del programa */
    if(!RegisterClassEx(&wincl)) return 0;
 
    /* La clase est� registrada, crear la ventana */
    hwnd = CreateWindowEx(
           0,                   /* Posibilidades de variaci�n */
           "NUESTRA_CLASE",     /* Nombre de la clase */
           "Ejemplo 010",       /* Texto del t�tulo */
           WS_OVERLAPPEDWINDOW, /* Tipo por defecto */
           CW_USEDEFAULT,       /* Windows decide la posici�n */
           CW_USEDEFAULT,       /* donde se coloca la ventana */
           544,                 /* Ancho */
           375,                 /* Alto en pixels */
           HWND_DESKTOP,        /* La ventana es hija del escritorio */
           NULL,                /* Sin men� */
           hThisInstance,       /* Manipulador de instancia */
           NULL                 /* No hay datos de creaci�n de ventana */
    );

    /* Mostrar la ventana */
    ShowWindow(hwnd, SW_SHOWDEFAULT);

    /* Bucle de mensajes, se ejecuta hasta que haya error o GetMessage devuelva FALSE */
    while(TRUE == GetMessage(&mensaje, NULL, 0, 0))
    {
        /* Traducir mensajes de teclas virtuales a mensajes de caracteres */
        TranslateMessage(&mensaje);
        /* Enviar mensaje al procedimiento de ventana */
        DispatchMessage(&mensaje);
    }

    /* Salir con valor de retorno */
    return mensaje.wParam;
}

/*  Esta funci�n es invocada por la funci�n DispatchMessage()  */
LRESULT CALLBACK WindowProcedure(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
    static HINSTANCE hInstance;
    static DATOS Datos;
    int i;
        
    switch (msg)                  /* manipulador del mensaje */
    {
        case WM_CREATE:
           hInstance = ((LPCREATESTRUCT)lParam)->hInstance;
           Datos.nCadenas = 6;
           strcpy(Datos.Item[0], "a");
           strcpy(Datos.Item[1], "c");
           strcpy(Datos.Item[2], "e");
           for(i = 0; i < Datos.nCadenas; i++) 
              sprintf(Datos.Lista[i], "%c) Opci�n %c", 'a'+i, 'A'+i);
           return 0;
           break;
        case WM_COMMAND:
           if(LOWORD(wParam) == CM_DIALOGO)
              DialogBoxParam(hInstance, "DialogoPrueba", hwnd, DlgProc, (LPARAM)&Datos); 
           break;
        case WM_DESTROY:
           PostQuitMessage(0);    /* env�a un mensaje WM_QUIT a la cola de mensajes */
           break;
        default:                  /* para los mensajes de los que no nos ocupamos */
           return DefWindowProc(hwnd, msg, wParam, lParam);
    }
    return 0;
}

BOOL CALLBACK DlgProc(HWND hDlg, UINT msg, WPARAM wParam, LPARAM lParam)
{
    UINT indice;
    int i;
    char resultado[250];
    static DATOS *Datos;
    
    switch (msg)                  /* manipulador del mensaje */
    {
        case WM_INITDIALOG:
           Datos = (DATOS*)lParam;
           // A�adir cadenas. Mensaje: LB_ADDSTRING
           for(i = 0; i < Datos->nCadenas; i++) {
              SendDlgItemMessage(hDlg, ID_COMBOBOX1, 
                 CB_ADDSTRING, 0, (LPARAM)Datos->Lista[i]);
              SendDlgItemMessage(hDlg, ID_COMBOBOX2, 
                 CB_ADDSTRING, 0, (LPARAM)Datos->Lista[i]);
              SendDlgItemMessage(hDlg, ID_COMBOBOX3, 
                 CB_ADDSTRING, 0, (LPARAM)Datos->Lista[i]);
           }
           SendDlgItemMessage(hDlg, ID_COMBOBOX1, CB_SELECTSTRING, 
              (WPARAM)-1, (LPARAM)Datos->Item[0]);
           SendDlgItemMessage(hDlg, ID_COMBOBOX2, CB_SELECTSTRING, 
              (WPARAM)-1, (LPARAM)Datos->Item[1]);
           SendDlgItemMessage(hDlg, ID_COMBOBOX3, CB_SELECTSTRING, 
              (WPARAM)-1, (LPARAM)Datos->Item[2]);
           SetFocus(GetDlgItem(hDlg, ID_COMBOBOX1));
           return FALSE;
        case WM_COMMAND:
           switch(LOWORD(wParam)) {
              case IDOK:
                 // En el ComboList Simple usaremos:
                 GetDlgItemText(hDlg, ID_COMBOBOX1, Datos->Item[0], 80);
                 if(SendDlgItemMessage(hDlg, ID_COMBOBOX1, CB_FINDSTRINGEXACT, 
                    (WPARAM)-1, (LPARAM)Datos->Item[0]) == CB_ERR)
                    strcpy(Datos->Lista[Datos->nCadenas++], Datos->Item[0]);
                 // En el ComboList DropDown usaremos:
                 SendDlgItemMessage(hDlg, ID_COMBOBOX2, WM_GETTEXT, 
                    80, (LPARAM)Datos->Item[1]);
                 if(SendDlgItemMessage(hDlg, ID_COMBOBOX1, CB_FINDSTRINGEXACT, 
                    (WPARAM)-1, (LPARAM)Datos->Item[1]) == CB_ERR &&
                    strcmp(Datos->Item[0], Datos->Item[1])) 
                    strcpy(Datos->Lista[Datos->nCadenas++], Datos->Item[1]);
                 // En el ComboList DropDownList usaremos:
                 indice = SendDlgItemMessage(hDlg, ID_COMBOBOX3, 
                    CB_GETCURSEL, 0, 0);
                 SendDlgItemMessage(hDlg, ID_COMBOBOX3, 
                    CB_GETLBTEXT, indice, (LPARAM)Datos->Item[2]);
                 wsprintf(resultado, "%s\n%s\n%s", 
                    Datos->Item[0], Datos->Item[1], Datos->Item[2]);
                 MessageBox(hDlg, resultado, "Leido", MB_OK);
                 EndDialog(hDlg, FALSE);
                 return TRUE;
              case IDCANCEL:
                 EndDialog(hDlg, FALSE);
                 return FALSE;
            }
    }
    return FALSE;
}

