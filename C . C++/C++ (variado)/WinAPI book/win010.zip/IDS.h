/* Identificadores */ 
#define MAX_CADENAS 100

/* Identificadores de comandos */
#define CM_DIALOGO 101

/* Identificadores de di�logo */
#define ID_COMBOBOX1 100
#define ID_COMBOBOX2 101
#define ID_COMBOBOX3 102

