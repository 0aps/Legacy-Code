// Identificadores de men�
#define CM_STOCK      100
#define CM_TRUETYPE   101
#define CM_ALIGN      102
#define CM_SEPARACION 103
#define CM_METRICS    104
#define CM_JUSTIFICAR 105

