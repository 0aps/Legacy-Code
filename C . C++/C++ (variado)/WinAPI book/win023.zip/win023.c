#include <windows.h>
#include <string.h>
#include "ids.h"

/* Declaraci�n del procedimiento de ventana */
LRESULT CALLBACK WindowProcedure(HWND, UINT, WPARAM, LPARAM);

void TrueType(HDC);
void Stock(HDC);
void Alineacion(HDC);
void Separacion(HDC);
void Metrics(HDC);
void Justificar(HWND, HDC);

int WINAPI WinMain (HINSTANCE hThisInstance,
                    HINSTANCE hPrevInstance,
                    LPSTR lpszArgument,
                    int nFunsterStil)
{
    HWND hwnd;               /* Manipulador de ventana */
    MSG mensaje;             /* Mensajes recibidos por la aplicaci�n */
    WNDCLASSEX wincl;        /* Estructura de datos para la clase de ventana */

    /* Estructura de la ventana */
    wincl.hInstance = hThisInstance;
    wincl.lpszClassName = "NUESTRA_CLASE";
    wincl.lpfnWndProc = WindowProcedure;      /* Esta funci�n es invocada por Windows */
    wincl.style = CS_DBLCLKS;                 /* Captura los doble-clicks */
    wincl.cbSize = sizeof (WNDCLASSEX);

    /* Usar icono y puntero por defector */
    wincl.hIcon = LoadIcon (hThisInstance, "Icono");
    wincl.hIconSm = LoadIcon (hThisInstance, "Icono");
    wincl.hCursor = LoadCursor (NULL, IDC_ARROW);
    wincl.lpszMenuName = "Menu";
    wincl.cbClsExtra = 0;                      /* Sin informaci�n adicional para la */
    wincl.cbWndExtra = 0;                      /* clase o la ventana */
    /* Usar el color de fondo por defecto para es escritorio */
    wincl.hbrBackground = GetSysColorBrush(COLOR_BACKGROUND);

    /* Registrar la clase de ventana, si falla, salir del programa */
    if(!RegisterClassEx(&wincl)) return 0;
      
    /* La clase est� registrada, crear la ventana */
    hwnd = CreateWindowEx(
           0,                   /* Posibilidades de variaci�n */
           "NUESTRA_CLASE",     /* Nombre de la clase */
           "Ejemplo 023",       /* Texto del t�tulo */
           WS_OVERLAPPEDWINDOW, /* Tipo por defecto */
           CW_USEDEFAULT,       /* Windows decide la posici�n */
           CW_USEDEFAULT,       /* donde se coloca la ventana */
           450,
           450,
           HWND_DESKTOP,        /* La ventana es hija del escritorio */
           NULL,                /* Sin men� */
           hThisInstance,       /* Manipulador de instancia */
           NULL                 /* No hay datos de creaci�n de ventana */
    );

    /* Mostrar la ventana */
    ShowWindow(hwnd, SW_SHOWDEFAULT);

    /* Bucle de mensajes, se ejecuta hasta que haya error o GetMessage devuelva FALSE */
    while(TRUE == GetMessage(&mensaje, NULL, 0, 0))
    {
        /* Traducir mensajes de teclas virtuales a mensajes de caracteres */
        TranslateMessage(&mensaje);
        /* Enviar mensaje al procedimiento de ventana */
        DispatchMessage(&mensaje);
    }

    /* Salir con valor de retorno */
    return mensaje.wParam;
}

/* Esta funci�n es llamada por la funci�n del API DispatchMessage() */
LRESULT CALLBACK WindowProcedure(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
    HDC hDC;
    PAINTSTRUCT ps;
    static UINT comando;
    
    switch (msg)                  /* manipulador del mensaje */
    {
        case WM_CREATE:
           comando = CM_TRUETYPE;
           break;
        case WM_PAINT:
           hDC = BeginPaint(hwnd, &ps);
           switch(comando) {
              case CM_STOCK:
                 Stock(hDC);
                 break;
              case CM_TRUETYPE:
                 TrueType(hDC);
                 break;
              case CM_ALIGN:
                 Alineacion(hDC);
                 break;
              case CM_SEPARACION:
                 Separacion(hDC);
                 break;
              case CM_METRICS:
                 Metrics(hDC);
                 break;
              case CM_JUSTIFICAR:
                 Justificar(hwnd, hDC);
                 break;
           }
           EndPaint(hwnd, &ps);
           break;
        case WM_COMMAND:
           comando = LOWORD(wParam);
           InvalidateRect(hwnd, NULL, TRUE);
           break;
        case WM_SIZE:
           InvalidateRect(hwnd, NULL, TRUE);
           break;
        case WM_DESTROY:
           PostQuitMessage(0);    /* env�a un mensaje WM_QUIT a la cola de mensajes */
           break;
        default:                  /* para los mensajes de los que no nos ocupamos */
           return DefWindowProc(hwnd, msg, wParam, lParam);
    }
    return 0;
}

void TrueType(HDC hDC) {
   HFONT fuente;
   HFONT grafico;
   COLORREF color;
   LOGFONT lf= {80, 0, 450, 450, 300, FALSE, FALSE, FALSE,
              DEFAULT_CHARSET, OUT_TT_PRECIS, CLIP_DEFAULT_PRECIS, 
              PROOF_QUALITY, DEFAULT_PITCH | FF_ROMAN, "Webdings"};

   fuente = CreateFont(-80, 0, 450, 450, 300, FALSE, FALSE, FALSE, 
      DEFAULT_CHARSET, OUT_TT_PRECIS, CLIP_DEFAULT_PRECIS, 
      PROOF_QUALITY, DEFAULT_PITCH | FF_ROMAN, "Times New Roman");
   grafico = CreateFontIndirect(&lf);

   SetBkMode(hDC, TRANSPARENT);        
   SelectObject(hDC, fuente);  
   TextOut(hDC, 10, 100, "Hola", 4);
   SelectObject(hDC, grafico);  
   TextOut(hDC, 120, 100, "\x23", 1);
   color = SetTextColor(hDC, RGB(255,255,0));
   SelectObject(hDC, fuente);  
   TextOut(hDC, 16, 106, "Hola", 4);
   SelectObject(hDC, grafico);  
   TextOut(hDC, 126, 106, "\x23", 1);
   SetTextColor(hDC, color);

   DeleteObject(fuente);
   DeleteObject(grafico);
}

void Stock(HDC hDC) {
   HFONT fuente, anterior;

   SetBkMode(hDC, TRANSPARENT);        

   fuente = GetStockObject(ANSI_FIXED_FONT);
   anterior = SelectObject(hDC, fuente);  
   TextOut(hDC, 10, 10, "ANSI_FIXED_FONT", 15);

   fuente = GetStockObject(ANSI_VAR_FONT);
   anterior = SelectObject(hDC, fuente);
   TextOut(hDC, 10, 30, "ANSI_VAR_FONT", 13);

   fuente = GetStockObject(DEVICE_DEFAULT_FONT);
   SelectObject(hDC, fuente);
   TextOut(hDC, 10, 50, "DEVICE_DEFAULT_FONT", 19);

   fuente = GetStockObject(OEM_FIXED_FONT);
   SelectObject(hDC, fuente);
   TextOut(hDC, 10, 70, "OEM_FIXED_FONT", 14);

   fuente = GetStockObject(SYSTEM_FONT);
   SelectObject(hDC, fuente);
   TextOut(hDC, 10, 90, "SYSTEM_FONT", 11);

   fuente = GetStockObject(SYSTEM_FIXED_FONT);
   SelectObject(hDC, fuente);
   TextOut(hDC, 10, 110, "SYSTEM_FIXED_FONT", 17);

   SelectObject(hDC, anterior);
   DeleteObject(fuente);
}

void Alineacion(HDC hDC) {
   HFONT fuente, anterior;
   HPEN pluma;

   SetBkMode(hDC, TRANSPARENT);
   SetBkColor(hDC, RGB(255,255,255));
   fuente = GetStockObject(SYSTEM_FONT);
   anterior = SelectObject(hDC, fuente);
   pluma = CreatePen(PS_DOT, 0, RGB(255,0,0));
   SelectObject(hDC, pluma);
   
   SetTextAlign(hDC, TA_BASELINE);
   TextOut(hDC, 10, 20, "TA_BASELINE", 11);
   MoveToEx(hDC, 10, 20, NULL); LineTo(hDC, 130, 20);
   MoveToEx(hDC, 10, 20, NULL); LineTo(hDC, 10, 0);

   SetTextAlign(hDC, TA_BOTTOM);
   TextOut(hDC, 10, 60, "TA_BOTTOM", 9);
   MoveToEx(hDC, 10, 60, NULL); LineTo(hDC, 130, 60);
   MoveToEx(hDC, 10, 60, NULL); LineTo(hDC, 10, 30);

   SetTextAlign(hDC, TA_TOP);
   TextOut(hDC, 10, 90, "TA_TOP", 6);
   MoveToEx(hDC, 10, 90, NULL); LineTo(hDC, 130, 90);
   MoveToEx(hDC, 10, 90, NULL); LineTo(hDC, 10, 120);

   SetTextAlign(hDC, TA_CENTER);
   TextOut(hDC, 100, 120, "TA_CENTER", 9);
   MoveToEx(hDC, 10, 120, NULL); LineTo(hDC, 200, 120);
   MoveToEx(hDC, 100, 115, NULL); LineTo(hDC, 100, 140);

   SetTextAlign(hDC, TA_LEFT);
   TextOut(hDC, 10, 150, "TA_LEFT", 7);
   MoveToEx(hDC, 10, 150, NULL); LineTo(hDC, 100, 150);
   MoveToEx(hDC, 10, 150, NULL); LineTo(hDC, 10, 170);

   SetTextAlign(hDC, TA_RIGHT);
   TextOut(hDC, 120, 180, "TA_RIGHT", 8);
   MoveToEx(hDC, 120, 180, NULL); LineTo(hDC, 10, 180);
   MoveToEx(hDC, 120, 180, NULL); LineTo(hDC, 120, 200);

   SetTextAlign(hDC, TA_RIGHT | TA_BOTTOM);
   TextOut(hDC, 180, 230, "TA_RIGHT | TA_BOTTOM", 20);
   MoveToEx(hDC, 180, 230, NULL); LineTo(hDC, 10, 230);
   MoveToEx(hDC, 180, 230, NULL); LineTo(hDC, 180, 200);

   SelectObject(hDC, anterior);
   DeleteObject(fuente);
   DeleteObject(pluma);
}

void Separacion(HDC hDC) {
   HFONT fuente, anterior;
   LOGFONT lf= {40, 0, 0, 0, 300, FALSE, FALSE, FALSE,
              DEFAULT_CHARSET, OUT_TT_PRECIS, CLIP_DEFAULT_PRECIS,
              PROOF_QUALITY, DEFAULT_PITCH | FF_ROMAN, "Arial"};

   fuente = CreateFontIndirect(&lf);

   SetBkMode(hDC, TRANSPARENT);

   anterior = SelectObject(hDC, fuente);
   TextOut(hDC, 10, 10, "Texto de prueba", 15);

   SetTextCharacterExtra(hDC, 10);
   TextOut(hDC, 10, 60, "Texto de prueba", 15);

   SelectObject(hDC, anterior);
   DeleteObject(fuente);
}

void Metrics(HDC hDC) {
   HFONT fuente, anterior;
   LOGFONT lf= {30, 0, 0, 0, 300, FALSE, FALSE, FALSE,
              DEFAULT_CHARSET, OUT_TT_PRECIS, CLIP_DEFAULT_PRECIS,
              PROOF_QUALITY, DEFAULT_PITCH | FF_ROMAN, "Comic Sans MS"};
   TEXTMETRIC tm;
   char cadena[128];
   int y = 10;
   
   fuente = CreateFontIndirect(&lf);
   SetBkMode(hDC, TRANSPARENT);
   anterior = SelectObject(hDC, fuente);

   GetTextMetrics(hDC, &tm);
   sprintf(cadena, "Altura = %d", tm.tmHeight);
   TextOut(hDC, 10, y, cadena, strlen(cadena));

   y += tm.tmExternalLeading + tm.tmHeight;
   sprintf(cadena, "Separaci�n externa = %d", tm.tmExternalLeading);
   TextOut(hDC, 10, y, cadena, strlen(cadena));

   y += tm.tmExternalLeading + tm.tmHeight;
   sprintf(cadena, "Anchura media = %d", tm.tmAveCharWidth);
   TextOut(hDC, 10, y, cadena, strlen(cadena));

   y += tm.tmExternalLeading + tm.tmHeight;
   sprintf(cadena, "Anchura m�xima = %d", tm.tmMaxCharWidth);
   TextOut(hDC, 10, y, cadena, strlen(cadena));

   y += tm.tmExternalLeading + tm.tmHeight;
   sprintf(cadena, "Altura ascendente = %d", tm.tmAscent);
   TextOut(hDC, 10, y, cadena, strlen(cadena));

   y += tm.tmExternalLeading + tm.tmHeight;
   sprintf(cadena, "Altura descendente = %d", tm.tmDescent);
   TextOut(hDC, 10, y, cadena, strlen(cadena));

   SelectObject(hDC, anterior);
   DeleteObject(fuente);
}

/*
void Justificar(HWND hwnd, HDC hDC) {
   HFONT fuente, anterior;
   LOGFONT lf= {20, 0, 0, 0, 0, FALSE, FALSE, FALSE,
              DEFAULT_CHARSET, OUT_TT_PRECIS, CLIP_DEFAULT_PRECIS,
              PROOF_QUALITY, DEFAULT_PITCH | FF_ROMAN, "Arial"};
   TEXTMETRIC tm;
   char *cadena[] = {
      "Para ello deberemos usar dos funciones de",
      "forma conjunta. Por una parte",
      "GetTextExtentPoint32, que nos proporciona",
      "informaci�n sobre el tama�o de una l�nea",
      "de texto. Por otra, la funci�n",
      "SetTextJustification, que prepara las",
      "cosas para que la siguiente funci�n de",
      "salida de texto TextOut incluya la",
      "separaci�n apropiada entre palabras."
   };
   int espacios[] = {6, 4, 3, 6, 5, 3, 6, 5, 3};
   int y = 10;
   int i, separacion;
   SIZE tam;
   RECT re;
   
   fuente = CreateFontIndirect(&lf);
   SetBkMode(hDC, TRANSPARENT);
   anterior = SelectObject(hDC, fuente);
   GetClientRect(hwnd, &re);
   
   GetTextMetrics(hDC, &tm);
   separacion = tm.tmExternalLeading + tm.tmHeight;

   // Texto justificado
   for(i = 0; i < sizeof(cadena)/sizeof(char*); i++) {
      SetTextJustification(hDC, 0, 0);
      GetTextExtentPoint32(hDC, cadena[i], strlen(cadena[i]), &tam);
      SetTextJustification(hDC, re.right-tam.cx-20, espacios[i]);
      TextOut(hDC, 10, y, cadena[i], strlen(cadena[i]));
      y += separacion;
   }
   SetTextJustification(hDC, 0, 0);
   y+=20;

   // Texto sin justificar
   for(i = 0; i < sizeof(cadena)/sizeof(char*); i++) {
      TextOut(hDC, 10, y, cadena[i], strlen(cadena[i]));
      y += separacion;
   }

   SelectObject(hDC, anterior);
   DeleteObject(fuente);
}
*/

void Justificar(HWND hwnd, HDC hDC) {
   HFONT fuente, anterior;
   LOGFONT lf= {20, 0, 0, 0, 0, FALSE, FALSE, FALSE,
              DEFAULT_CHARSET, OUT_TT_PRECIS, CLIP_DEFAULT_PRECIS,
              PROOF_QUALITY, DEFAULT_PITCH | FF_ROMAN, "Arial"};
   TEXTMETRIC tm;
   char *cadena = 
      "Para ello deberemos usar dos funciones de "
      "forma conjunta. Por una parte "
      "GetTextExtentPoint32, que nos proporciona "
      "informaci�n sobre el tama�o de una l�nea "
      "de texto. Por otra, la funci�n "
      "SetTextJustification, que prepara las "
      "cosas para que la siguiente funci�n de "
      "salida de texto TextOut incluya la "
      "separaci�n apropiada entre palabras.";
   char *actual = cadena;
   int palabras;
   int y = 10;
   int i, j, separacion;
   SIZE tam;
   RECT re;
   char cad[512];
   
   fuente = CreateFontIndirect(&lf);
   SetBkMode(hDC, TRANSPARENT);
   anterior = SelectObject(hDC, fuente);
   GetClientRect(hwnd, &re);
   
   GetTextMetrics(hDC, &tm);
   separacion = tm.tmExternalLeading + tm.tmHeight;

   // Texto justificado
   do {
      palabras = 0;
      j=0;
      SetTextJustification(hDC, 0, 0);
      SetTextCharacterExtra(hDC, 0);
      // A�adir palabras mientras quepan en una l�nea:
      do {
         while(actual[j] && actual[j] != ' ') {
            j++;
         }
         palabras++;
         GetTextExtentPoint32(hDC, actual, j, &tam);
         if(actual[j] == ' ') j++;
      } while(actual[j] && tam.cx <= re.right-20);
      // Quitar la �ltima palabra, s�lo si es necesario, y si hay
      // m�s de una:
      if(tam.cx > re.right-20) {
         if(palabras > 1) {
            j-=2;
            if(actual[j]) {
               while(actual[j] != ' ') j--;
            }
            palabras--;
         }
         
         GetTextExtentPoint32(hDC, actual, j, &tam);
         if(palabras == 1) {
            // Una �nica palabra, justificar separando letras
            SetTextCharacterExtra(hDC, (re.right-20-tam.cx)/(j-1));
         }
         else {
            SetTextJustification(hDC, re.right-tam.cx-20, palabras-1);
         }
      } // else: �ltima l�nea de p�rrafo.
      TextOut(hDC, 10, y, actual, j);
      actual+=j;
      // Avanzar hasta siguiente palabra, saltarse espacios:
      while(*actual == ' ') actual++;
      y += separacion;
   } while(*actual);
   
   SetTextJustification(hDC, 0, 0);
   y+=20;

   // Texto sin justificar
   actual = cadena;
   do {
      palabras = 0;
      j=0;
      SetTextJustification(hDC, 0, 0);
      SetTextCharacterExtra(hDC, 0);
      // A�adir palabras mientras quepan en una l�nea:
      do {
         while(actual[j] && actual[j] != ' ') {
            j++;
         }
         palabras++;
         GetTextExtentPoint32(hDC, actual, j, &tam);
         if(actual[j] == ' ') j++;
      } while(actual[j] && tam.cx <= re.right-20);
      // Quitar la �ltima palabra, s�lo si es necesario, y si hay
      // m�s de una:
      if(tam.cx > re.right-20) {
         if(palabras > 1) {
            j-=2;
            if(actual[j]) {
               while(actual[j] != ' ') j--;
            }
            palabras--;
         }
      }
      TextOut(hDC, 10, y, actual, j);
      actual+=j;
      // Avanzar hasta siguiente palabra, saltarse espacios:
      while(*actual == ' ') actual++;
      y += separacion;
   } while(*actual);

   SelectObject(hDC, anterior);
   DeleteObject(fuente);
}

