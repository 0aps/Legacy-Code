/* Identificadores */ 

/* Identificadores de comandos */
#define CM_DIALOGO 101

/* Identificadores de di�logo */
#define ID_TEXTO 100

