// Identificadores de men�
#define CM_RECTANGULO     100
#define CM_RECTREDONDEADO 101
#define CM_ELIPSE         102
#define CM_POLIGONO       103
#define CM_POLIPOLIGONO   104

#define CM_AND            200
#define CM_COPY           201
#define CM_DIFF           202
#define CM_OR             203
#define CM_XOR            204

#define CM_FILL           300
#define CM_PAINT          301
#define CM_INVERT         302
#define CM_FRAME          303

