#include <windows.h>
#include "ids.h"

/* Declaraci�n del procedimiento de ventana */
LRESULT CALLBACK WindowProcedure(HWND, UINT, WPARAM, LPARAM);

int WINAPI WinMain (HINSTANCE hThisInstance,
                    HINSTANCE hPrevInstance,
                    LPSTR lpszArgument,
                    int nFunsterStil)
{
    HWND hwnd;               /* Manipulador de ventana */
    MSG mensaje;             /* Mensajes recibidos por la aplicaci�n */
    WNDCLASSEX wincl;        /* Estructura de datos para la clase de ventana */

    /* Estructura de la ventana */
    wincl.hInstance = hThisInstance;
    wincl.lpszClassName = "NUESTRA_CLASE";
    wincl.lpfnWndProc = WindowProcedure;      /* Esta funci�n es invocada por Windows */
    wincl.style = CS_DBLCLKS;                 /* Captura los doble-clicks */
    wincl.cbSize = sizeof (WNDCLASSEX);

    /* Usar icono y puntero por defector */
    wincl.hIcon = LoadIcon (hThisInstance, "Icono");
    wincl.hIconSm = LoadIcon (hThisInstance, "Icono");
    wincl.hCursor = LoadCursor (NULL, IDC_ARROW);
    wincl.lpszMenuName = "Menu";
    wincl.cbClsExtra = 0;                      /* Sin informaci�n adicional para la */
    wincl.cbWndExtra = 0;                      /* clase o la ventana */
    /* Usar el color de fondo por defecto para es escritorio */
    wincl.hbrBackground = GetSysColorBrush(COLOR_BACKGROUND);

    /* Registrar la clase de ventana, si falla, salir del programa */
    if(!RegisterClassEx(&wincl)) return 0;
      
    /* La clase est� registrada, crear la ventana */
    hwnd = CreateWindowEx(
           0,                   /* Posibilidades de variaci�n */
           "NUESTRA_CLASE",     /* Nombre de la clase */
           "Ejemplo 025",       /* Texto del t�tulo */
           WS_OVERLAPPEDWINDOW, /* Tipo por defecto */
           CW_USEDEFAULT,       /* Windows decide la posici�n */
           CW_USEDEFAULT,       /* donde se coloca la ventana */
           450,
           450,
           HWND_DESKTOP,        /* La ventana es hija del escritorio */
           NULL,                /* Sin men� */
           hThisInstance,       /* Manipulador de instancia */
           NULL                 /* No hay datos de creaci�n de ventana */
    );

    /* Mostrar la ventana */
    ShowWindow(hwnd, SW_SHOWDEFAULT);

    /* Bucle de mensajes, se ejecuta hasta que haya error o GetMessage devuelva FALSE */
    while(TRUE == GetMessage(&mensaje, NULL, 0, 0))
    {
        /* Traducir mensajes de teclas virtuales a mensajes de caracteres */
        TranslateMessage(&mensaje);
        /* Enviar mensaje al procedimiento de ventana */
        DispatchMessage(&mensaje);
    }

    /* Salir con valor de retorno */
    return mensaje.wParam;
}

/* Esta funci�n es llamada por la funci�n del API DispatchMessage() */
LRESULT CALLBACK WindowProcedure(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
    HDC hdc;
    PAINTSTRUCT ps;
    static HINSTANCE hInstance;
    static HRGN hRegion;
    static HRGN hReg1;
    static HRGN hReg2;
    static HBRUSH pincel;
    static POINT puntos[] = {10,90, 210,90, 50,210, 110,10, 170,210,
                             220,10, 420,10, 420, 210, 220,210};
    static INT npuntos[] = {5,4};
    static WORD modo;

    switch (msg)                  /* manipulador del mensaje */
    {
        case WM_CREATE:
           hInstance = ((LPCREATESTRUCT)lParam)->hInstance;
           pincel = CreateSolidBrush(RGB(255,0,0));
           hRegion = CreateRectRgn(10,10,400,200);
           hReg1 = CreateRectRgn(10,10,200,200);
           hReg2 = CreateEllipticRgn(110,110,300,300);
           modo = CM_FILL;
           break;
        case WM_PAINT:
           hdc = BeginPaint(hwnd, &ps);
           switch(modo) {
              case CM_FILL:
                 FillRgn(hdc, hRegion, pincel);
                 break;
              case CM_INVERT:
                 InvertRgn(hdc, hRegion);
                 break;
              case CM_PAINT:
                 PaintRgn(hdc, hRegion);
                 break;
              case CM_FRAME:
                 FrameRgn(hdc, hRegion, pincel, 4, 4);
                 break;
           }
           EndPaint(hwnd, &ps);
           break;
        case WM_COMMAND:
           switch(LOWORD(wParam)) {
              case CM_RECTANGULO:
                 DeleteObject(hRegion);
                 hRegion = CreateRectRgn(10,10,400,200);
                 break;
              case CM_RECTREDONDEADO:
                 DeleteObject(hRegion);
                 hRegion = CreateRoundRectRgn(10,10,400,200,50,50);
                 break;
              case CM_ELIPSE:
                 DeleteObject(hRegion);
                 hRegion = CreateEllipticRgn(10,10,400,200);
                 break;
              case CM_POLIGONO:
                 DeleteObject(hRegion);
                 hRegion = CreatePolygonRgn(puntos, 5, ALTERNATE);
                 break;
              case CM_POLIPOLIGONO:
                 DeleteObject(hRegion);
                 hRegion = CreatePolyPolygonRgn(puntos, npuntos, 2, WINDING);
                 break;
              case CM_AND:
                 CombineRgn(hRegion, hReg1, hReg2, RGN_AND);
                 break;
              case CM_COPY:
                 CombineRgn(hRegion, hReg1, hReg2, RGN_COPY);
                 break;
              case CM_DIFF:
                 CombineRgn(hRegion, hReg1, hReg2, RGN_DIFF);
                 break;
              case CM_OR:
                 CombineRgn(hRegion, hReg1, hReg2, RGN_OR);
                 break;
              case CM_XOR:
                 CombineRgn(hRegion, hReg1, hReg2, RGN_XOR);
                 break;
              case CM_FRAME:
              case CM_FILL:
              case CM_INVERT:
              case CM_PAINT:
                 modo = LOWORD(wParam);
                 break;
           }
           InvalidateRect(hwnd, NULL, TRUE);
           break;
        case WM_DESTROY:
           DeleteObject(hRegion);
           DeleteObject(hReg1);
           DeleteObject(hReg2);
           DeleteObject(pincel);
           PostQuitMessage(0);    /* env�a un mensaje WM_QUIT a la cola de mensajes */
           break;
        default:                  /* para los mensajes de los que no nos ocupamos */
           return DefWindowProc(hwnd, msg, wParam, lParam);
    }
    return 0;
}

