#include <wx/string.h>
#include <wx/url.h>
#include <wx/file.h>
#include <wx/wfstream.h>
#include <wx/utils.h>
#include <wx/txtstrm.h> 
#include <wx/app.h>

int main ( int argc, char * argv[] )
{
	if (wxInitialize() == false) 
	{
		wxPuts ( wxT ( "Error al inicializar las wxWidgets.\n" ) );
		return -1;
	}

	//wxString urlname = wxT ( "http://josefina.engendro.laweb.es/apps/JZO-tools.php?CmdLineTools=MiIP" );
	wxString urlname = wxT ( "http://www.tinet.cat/~acl/cgi-bin/CualEsMiIP.cgi?CmdLineTools=verStrMiIP" );
	wxURL url( urlname );

	if ( url.GetError() != wxURL_NOERR )
	{
		wxPuts ( wxT ( "Error: No puedo conectar con el servidor." ) );
		wxPuts ( wxT ( "       El servidor puede que  haya caido." ) );
		wxPuts ( wxT ( "       Intentalo dentro  de unos minutos.\n\n" ) );
		wxUninitialize();
		return -1;
	}

	wxYield();

	wxInputStream * datos = url.GetInputStream(); 

	if ( !datos )
	{
		wxPuts ( wxT ( "Error: Lectura imposible. SoRRY\n\n" ) );
		wxUninitialize();
		return -1;
	}

	wxYield();

	while ( datos && datos->CanRead() && !datos->Eof() )
	{
		wxTextInputStream datosTexto ( * datos );
		wxPuts ( datosTexto.ReadLine () );
	}
	delete datos;
	wxPuts ( wxT ( "\n-----<(| M 3 'I' 4 L |)>-----\n" ) );
	wxUninitialize();
	return 0;
}

