#include <stdio.h>
#include <stdlib.h>
#if defined ( __unix__ ) || defined ( __VMS )
	#include <netdb.h>
	#include <sys/socket.h>
#elif defined ( _WIN32 )
	#include <windows.h>
#endif
#include <string.h>

char BufferEnvio [ 512 ], BufferReceptor [ 1024 ];

int main ( int argc, char * argv [] )
{
	#if defined ( __unix__ ) || defined ( __VMS )
		#define INVALID_SOCKET -1
		#define SOCKET_ERROR -1
		#define closesocket close
		int socketConexion;
	#elif defined ( _WIN32 )
		int respuesta;
		WSADATA wsaData;
		//Inicializamos la librer�a de sockets
		respuesta = WSAStartup ( MAKEWORD ( 1, 0 ), &wsaData );
		if ( respuesta )
		{
			puts ( "Error al inicializar la librer�a para socket" );
			puts ( "\nPulsa return para finalizar ..." );
			getchar ();
			return -1;
		}
		SOCKET socketConexion;
	#endif

	struct sockaddr_in servidor;
	struct hostent * direccionServidor;
  
	//direccionServidor = ( struct hostent * ) gethostbyname ( "cph.engendro.laweb.es" );
    direccionServidor = ( struct hostent * ) gethostbyname ( "www.tinet.cat" );

	if ( !direccionServidor )
	{
		puts ( "No se ha podido establecer la comunicaci�n con el servidor ..." );
		puts ( "\n\nPulsa return para finalizar ..." );
		getchar ();
		#if defined ( __unix__ ) || defined ( __VMS )
			return -1;
		#elif defined ( _WIN32 )
			WSACleanup();
			return WSAGetLastError();
		#endif
	}

	// Creamos el socket...
	socketConexion = socket ( AF_INET, SOCK_STREAM, 0 );
	if ( socketConexion == INVALID_SOCKET )
	{
		puts ( "Error al crear socket" );
		puts ( "\nPulsa return para finalizar ..." );
		getchar ();
		#if defined ( __unix__ ) || defined ( __VMS )
			perror ( "error socket" );
			return -1;
		#elif defined ( _WIN32 )
			WSACleanup ();
			return WSAGetLastError ();
		#endif
	}
   
	memset ( &servidor, 0, sizeof ( servidor ) );
	memcpy ( &servidor.sin_addr, direccionServidor->h_addr, direccionServidor->h_length );
	servidor.sin_family = direccionServidor->h_addrtype;
	servidor.sin_port = htons ( 80 ); // Conectamos al puerto del servidor web

	// Nos conectamos con el servidor...
	if ( connect ( socketConexion, ( struct sockaddr * )&servidor, sizeof ( servidor ) ) == SOCKET_ERROR )
	{
		printf ( "Error en la conexi�n con el servidor\n" );
		closesocket ( socketConexion );
		#if defined ( __unix__ ) || defined ( __VMS )
			perror ( "error de conexi�n" );
			puts ( "\nPulsa return para finalizar ..." );
			return;
		#elif defined ( _WIN32 )
			WSACleanup ();
			puts ( "\nPulsa return para finalizar ..." );
			getchar ();
			return WSAGetLastError ();
		#endif
	}
	printf("Conectado a: %s:%d\n", inet_ntoa ( servidor.sin_addr ), ntohs ( servidor.sin_port ) );

	// datos que vamos a enviar
	//strcpy(BufferEnvio,"GET /apps/JZO-tools.php?CmdLineTools=verStrMiIP HTTP/1.0\r\n\r\n");
	strcpy(BufferEnvio,"GET /~acl/cgi-bin/CualEsMiIP.cgi?CmdLineTools=verStrMiIP HTTP/1.0\r\n\r\n");
	//Enviamos y recibimos datos...
	printf ( "Enviando datos ... \n" );
	send ( socketConexion, BufferEnvio, sizeof ( BufferEnvio ), 0 );
	printf ( "Se ha enviado: %s \n", BufferEnvio );
	printf ( "Recibiendo ... \n" );
	recv ( socketConexion, BufferReceptor, sizeof ( BufferReceptor ), 0 );
	printf ( "Respuesta: %s \n\n", BufferReceptor );

	puts ( "\n------<(| M 3 'I' 4 L |)>------\n" );
	puts ( "\nPulsa return para finalizar ..." );
	getchar ();

	// Cerramos el socket y liberamos la DLL de sockets
	closesocket ( socketConexion );
	#if defined ( _WIN32 )
		WSACleanup();
	#endif
	return EXIT_SUCCESS;
}

