<?php
/*
 * file JZO-tools.php
 * Copyright by .xAk. AnimAlf@users.sf.net
 *
 * This lines are under the GNU General Public License.
 * http://www.gnu.org/copyleft/gpl.html
 *
 * onLine http://cph.engendro.laweb.es/apps/JZO-tools.php
 *
 * Info http://foro.portalhacker.net/index.php/topic,87446.msg410452.html
 */

/*
 * Recogemos la llamada de la url si está bién escrita
 * y terminamos.
 */
if ( isset ( $_GET [ "CmdLineTools" ] ) )
	salidaNavegador ( $_GET [ "CmdLineTools" ] );
else { header ( "Content-type: text/plain" ); echo "JZO tools v 0.1\n"; }

/*
 * función Conseguir_IP_Real
 *
 * Intenta devolver la ip del cliente o la mas cercana.
 */
function Conseguir_IP_Real () {
	/*
	 * Si se navega entre proxies encadenados, estos se van direccionando
	 * y añadiendose al array HTTP_X_FORWARDED_FOR de la variable del servidor
	 * web siendo la última la del visitante o la más cercana a la petición.
	 */
	if ( isset ( $_SERVER [ 'HTTP_X_FORWARDED_FOR' ] ) &&
		$_SERVER [ 'HTTP_X_FORWARDED_FOR' ] != '' 
	){
		$ip_visitante = ( !empty ( $_SERVER [ 'REMOTE_ADDR' ] ) )
			? $_SERVER[ 'REMOTE_ADDR' ]
			: ( ( !empty($_ENV[ 'REMOTE_ADDR' ] ) )
				?  $_ENV [ 'REMOTE_ADDR' ]
				: "unknown"
		);   
		$entries = split( '[, ]' , $_SERVER [ 'HTTP_X_FORWARDED_FOR' ] );
   
		reset ( $entries );
		while ( list ( , $entry ) = each ( $entries ) )
		{
			$entry = trim ( $entry );
			if ( preg_match ( "/^([0-9]+.[0-9]+.[0-9]+.[0-9]+)/", $entry, $lista_IPs ) )
			{
				/*
				 * Array de regex (regular expression) con las id's
				 * de las ip's reservadas para redes privadas
				*/
				$ip_lan = array (
					'/^0./',
					'/^127.0.0.1/',
					'/^192.168..*/',
					'/^172.((1[6-9])|(2[0-9])|(3[0-1]))..*/',
					'/^10..*/'
				);
   
				$ip_localizada = preg_replace ( $ip_lan, $ip_visitante, $lista_IPs [ 1 ] );
   
				if ( $ip_visitante != $ip_localizada )
				{
					$ip_visitante = $ip_localizada;
					break;
				}
			}
		}
	} else {
		/*
		 * en caso de no localizarla en el servidor web, intentaremos
		 * recogerla del entorno del sistema y nos daremos por vencidos
		 */
		$ip_visitante = (
			// Si no está en la variable del servidor
			!empty ( $_SERVER [ 'REMOTE_ADDR' ] ) )
			? 
				$_SERVER [ 'REMOTE_ADDR' ]
			: 
				// comprobamos que no esté en el entorno del sistema
				( ( !empty ( $_ENV [ 'REMOTE_ADDR' ] ) ) 
				?
					$_ENV [ 'REMOTE_ADDR' ]
				:
					"desconocida :-)"
		);
	}
	return $ip_visitante;
}

/*
 * función Conseguir_IP_Real
 *
 * Intenta devolver la ip del cliente o la mas cercana.
 */
function salidaNavegador ( $idModo )
{
	switch ( $idModo )
	{
		case "verStrMiIP": //en el navegador: ?CmdLineTools=verStrMiIP
			// El tipo mime que es lo primero que debe lanzar el navegador
			// será del tipo texto.
			header ( "Content-charset: UTF-8" );
			header ( "Content-Language: es" );
			header ( "Content-type: text/plain" );
			echo date ( 'l F d, Y  h:i:s A' );
			echo "\n************************************************\n";
			echo "******                                    ******\n";
			echo "******         - Cual es mi IP -          ******\n";
			echo "******                                    ******\n";
			echo "******      by: CPH MenToЯinG group       ******\n";
			echo "******                                    ******\n";
			echo "************************************************\n\n";
		 	$laIp = Conseguir_IP_Real ();
			echo "Tu IP  es: $laIp\n";
			if ( gethostbyaddr ( $laIp ) != $laIp )
				echo "Su nombre: " . gethostbyaddr ( $laIp );
			break;
		case "MiIPparaApp": //en el navegador: ?CmdLineTools=MiIPparaApp
			header ( "Content-type: text/plain" );
		 	$laIp = Conseguir_IP_Real ();
			echo "$laIp\n";
			if ( gethostbyaddr ( $laIp ) != $laIp )
				echo gethostbyaddr ( $laIp );
			break;
		default:
			header("Location: http://foro.portalhacker.net");
	}
}
?>

