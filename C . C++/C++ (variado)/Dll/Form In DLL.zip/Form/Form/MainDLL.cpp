#include <windows.h>

extern int Main(); //tells compiler that function Main is located somewhere else.

void WINAPI MainThread( )
{
	//This function will run when we attach the DLL to the Game//
	Main(); //located in Form1.cpp, This will load the form and display it
	//We will Create our Main() function later. 

}

//MyDLL is the name of your Project. If your Project is called 
//MapleHaxV1 you'll need to change MyDLL to using namespace MapleHaxV1

BOOL WINAPI DllMain ( HMODULE hModule, DWORD dwReason, LPVOID lpvReserved )
{
	switch ( dwReason ) {
		case DLL_PROCESS_ATTACH:

			DisableThreadLibraryCalls(hModule);

			if ( CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE)MainThread, NULL, 0, NULL) == NULL ) {
				return FALSE;
			}
			break;

		case DLL_PROCESS_DETACH:
			break;

		case DLL_THREAD_ATTACH:
			break;

		case DLL_THREAD_DETACH:
			break;
	}
	return TRUE;
}